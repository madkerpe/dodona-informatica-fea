dna = str(input())

A = dna.count("A")
T = dna.count("T")
G = dna.count("G")
C = dna.count("C")
    
l = [A, T, G, C]
print(l)
