s = input()
l = [int(i) for i in s.split(',')]
a = int(input())
b = int(input())

p = [ a <= i and i <= b for i in l]

print(p)