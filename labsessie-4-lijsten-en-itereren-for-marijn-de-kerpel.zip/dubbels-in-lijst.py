s = input()
l = [int(i) for i in s.split(',')]
dubbel = 0
l.sort()

for i in range(0,(len(l)-1)):
    
    dubbel += (l[i] == l[i + 1])
    
print(dubbel >= 1)

