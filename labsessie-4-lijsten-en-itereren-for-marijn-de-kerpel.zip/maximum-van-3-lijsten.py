s1 = input()
s2 = input()
s3 = input()

l1 = [int(i) for i in s1.split(',')]
l2 = [int(i) for i in s2.split(',')]
l3 = [int(i) for i in s3.split(',')]

templijst = []
maxlijst = []

for i in range(0, len(l1)):
    templijst.append(l1[i])
    templijst.append(l2[i])
    templijst.append(l3[i])
    maxlijst.append(max(templijst))
    templijst.clear()
print(maxlijst)
