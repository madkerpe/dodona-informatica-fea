n = int(input())
lijst = list(range(2, (n + 1)))
priemlijst = []

for i in range(2, (n + 1)):
    if len(lijst) != 0:                 #In plaats van deze if kon ik ook de                                 # "gemarkeerde" getallen gelijk                                     #stellen aan 1 of 0
        p = int(min(lijst))
        priemlijst.append(p)
    
        for j in range(1, (n + 1)):
            if j*p in lijst:
                lijst.remove(j*p)
            
        
    

print(priemlijst)
