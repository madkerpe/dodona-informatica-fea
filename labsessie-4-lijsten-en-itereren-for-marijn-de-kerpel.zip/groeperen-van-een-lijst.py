s = input()
l = [int(i) for i in s.split(',')]
g = int(input())
termen = len(l)//g
somlijst = []

for i in range(0, termen):    
    lijst = l.copy()
    som = sum(lijst[(i*g):(i + 1)*g])
    somlijst.append(som)
    lijst.clear()

print(somlijst)