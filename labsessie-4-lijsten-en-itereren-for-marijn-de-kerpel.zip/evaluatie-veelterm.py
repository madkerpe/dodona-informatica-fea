s = input()
l = [float(i) for i in s.split(',')]
x = float(input())
Vx = 1

for i in l:
    Vx *= (x - i)


print(Vx)