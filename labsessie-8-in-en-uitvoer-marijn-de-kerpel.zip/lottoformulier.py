
def leesFormulier(bestand):        
    lijst = []    
    antwoordlijst = []
    i = 1   
    
    try:        
        with open(bestand, 'r') as source:            
            for line in source:
                lijst.append(line.split())
        
        lijst = [item for sublist in lijst for item in sublist]    
        antwoordlijst.append(lijst[0])
        lijst = lijst[1:]
  
    
        for nummer in lijst:
            if nummer != str(i):
                antwoordlijst.append(i)
            i += 1
    
        return tuple(antwoordlijst)
        
    except:
        tup = ('X',0)
        return tup