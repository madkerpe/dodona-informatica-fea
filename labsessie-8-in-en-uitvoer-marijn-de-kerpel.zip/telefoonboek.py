def zoekNummer(telefoonbestand, voornaam, familienaam):
    telefoon_nummers = []
    
    with open(telefoonbestand, 'r') as source:
        lijst = [line.strip().split(', ') for line in source]
        for i in range(len(lijst)):
            if lijst[i][0] == voornaam and lijst[i][1] == familienaam:
                telefoon_nummers.append(lijst[i][2])   
    
    return telefoon_nummers
    
    