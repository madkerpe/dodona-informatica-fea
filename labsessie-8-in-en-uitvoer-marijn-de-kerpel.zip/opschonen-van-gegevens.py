def filter(dataIn, dataOut):
    with open(dataIn, 'r') as source:
        lijst = [item.strip() for item in source]
        
    
    fouten = 0    
    with open(dataOut, 'w') as target:
        
        for i in lijst:
            try:
                int(i)
                target.write(i)
                target.write('\n')
            
            except:
                fouten += 1
    
    return fouten
