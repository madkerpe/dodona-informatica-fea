def regelnummers(bron, doel):
    with open(bron, 'r') as source:
        with open(doel, 'w') as target:
            i = 0
            for line in source:

                target.write(str(i) + ":" + line)
                i += 1