def histogram(bestand, n):
   
    with open(bestand, 'r') as source:
        lijst = [float(item.strip()) for item in source]
       
    maxi = max(lijst)
    mini = min(lijst)
    lengte_interval = (abs(maxi - mini))/n

    antwoordlijst = [] 
   
    for i in range(n):
        term = 0     
        for item in lijst: 
            if i != (n - 1):
                if item >= (mini + i*lengte_interval) and item < mini + ((i + 1)*lengte_interval):
                    term += 1
            else:
                if item > (mini + i*lengte_interval):
                    term += 1
        antwoordlijst.append(term)

    return antwoordlijst