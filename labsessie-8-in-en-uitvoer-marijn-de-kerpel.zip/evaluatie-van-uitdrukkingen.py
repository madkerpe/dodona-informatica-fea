def evalueer(bestand, lijst):
    resultatenlijst = []
    for tup in lijst:
        x = tup[0]
        y = tup[1]
        z = tup[2]
        result = []
        with open(bestand, 'r') as source: #open het bestand in een lus
            for line in source:
                a = eval(line)
                result.append(a)
        resultatenlijst.append(tuple(result)) #tuple maken van een lijst met tuple()
    
    return resultatenlijst