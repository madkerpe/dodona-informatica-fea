def maakTabel(text):                            # maakt tabel rij x kolom
    tabel = []
    lines = text.readlines()
    for i in lines:
        lijst = i.split('\t')
        for j, k in enumerate(lijst):
            lijst[j] = int(k)
        tabel.append(lijst)
    return tabel

def schrijfKaart(inFile, outFile):
    with open(inFile, 'r') as mijn:
        tabel = maakTabel(mijn)
        with open(outFile, 'w') as kaart:    
            for i in range(0, len(tabel)):          # rij
                for j in range(0, len(tabel[0])):    # kolom
                    if j == (len(tabel[0]) - 1):
                        kaart.write('.\n')
                    elif  i == 0 or  i == (len(tabel) - 1):
                        kaart.write('.\t')
                    elif j == 0:
                        kaart.write('.\t')
                    else:
                        gemiddelde = (tabel[i-1][j] + tabel[i+1][j] + tabel[i][j-1] + tabel[i][j+1])/4
                        if tabel[i][j] > gemiddelde:
                            kaart.write('X\t')
                        else:
                            kaart.write('.\t')