import numpy as np

def manhattan(a,b):
    
    if len(a) != len(b):
        return -1.0
        
    return np.sum(abs(a-b))