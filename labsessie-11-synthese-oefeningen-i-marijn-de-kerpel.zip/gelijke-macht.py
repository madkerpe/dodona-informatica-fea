def gelijkeMacht(n, m):
    resultaat = []
    
    for i in range(m):
        for j in range(m):
            
            if (i**n)%m == (j**n)%m and i != j and (i != 0 or j != 0) and i < j:
                resultaat.append((i, j))
                
    
    resultaat = resultaat
    return resultaat
            