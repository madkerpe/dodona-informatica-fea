import numpy as np

def grens(d, a):
    if a <= 0:
        return np.min(d) -1
    
    for g in range(np.min(d)-1, np.max(d)+1):
        rij = d.copy()
        voorwaarde = rij <= g
        
        if len(rij[voorwaarde]) >= a:
            return g