def kMeren(tekst, lengte):
    
    meren = []
    
    
    if lengte < len(tekst):
        
        meren.append(tekst[0:lengte])
        for i in range(len(tekst) - lengte + 1):
            if tekst[i:i + lengte] not in meren:
                meren.append(tekst[i:i + lengte])
    
    elif lengte == len(tekst):        
        meren.append(tekst[0:lengte])
    
    return meren