import numpy as np

def aangeschakeld(rij, grens):
    rij = np.asarray(rij)
    voorwaarde_aan = rij > grens    
    
    posities_aan = np.arange(len(rij))[voorwaarde_aan]
    return (posities_aan[0], posities_aan[-1])