import math

def productVorm(n, m):
    
    for base in range(1, math.ceil(n**(1/float(m)))):
        
        product = 1
        for i in range(m):
            product *= base + i
        
    
        if product == n:
            return base
    return -1
    
    
    
    
    
    