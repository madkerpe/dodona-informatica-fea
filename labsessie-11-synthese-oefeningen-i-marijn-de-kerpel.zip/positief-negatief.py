def positiefNegatief(lijst):
    neg_lijst = []
    pos_lijst = []
    
    for i in lijst:
        if i >= 0:
            pos_lijst.append(i)
            
        else:
            neg_lijst.append(i)
    
    return neg_lijst + pos_lijst