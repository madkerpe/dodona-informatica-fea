def isMogelijk(sjabloon, opl):
    
    if len(sjabloon) != len(opl):
        return False
    
    for index,letter in enumerate(opl):
        if letter != sjabloon[index] and str(sjabloon[index]) != "?":
            return False
    return True