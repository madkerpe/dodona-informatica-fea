def afstand(a, b):
    
    verschil = abs(len(a)-len(b))
    if len(a) > len(b):
        langste = a
        kortste = b
    elif len(a) < len(b) or len(a) == len(b):
        langste = b
        kortste = a
    
    
    ongelijkheden = 0
    
    for index, letter in enumerate(kortste):
        if letter != langste[index]:
            ongelijkheden += 1
    
    
    
    return int(verschil + ongelijkheden)