def comprimeer(lijst):
    #zoeken naar n
    n_waarde = max([(lijst.count(i), i) for i in lijst])[0]
    n = min([i for i in lijst if lijst.count(i) == n_waarde])
    
    #steken in de dictionary
    wb = {}    
    
    for i, e in enumerate(lijst):
        if e != n:
            wb[i] = e
            
    return wb, n