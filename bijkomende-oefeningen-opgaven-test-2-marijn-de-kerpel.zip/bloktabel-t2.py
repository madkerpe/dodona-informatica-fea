import numpy as np

def blok(M, N, m, n):
    hoek_blok = np.ones(n*m).reshape(m,n)
    top_mid_blok = np.zeros(m*(N-2*n)).reshape(m,N-2*n)

    
    top_bun = np.concatenate((hoek_blok, top_mid_blok, hoek_blok), axis=1)

    bottom_bun = np.concatenate((hoek_blok, top_mid_blok, hoek_blok), axis=1)
    
    mid_zij_blok = np.zeros((M-2*m)*n).reshape((M-2*m),n)

    mid_blok = np.ones((M-2*m)*(N-2*n)).reshape((M-2*m), (N-2*n))

    meat = np.concatenate((mid_zij_blok, mid_blok, mid_zij_blok), axis=1)

    
    burger = np.concatenate((top_bun, meat, bottom_bun), axis=0)
    
    return burger