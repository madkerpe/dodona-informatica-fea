import numpy as np

def grootste4_eerst(tabel):
    tabel4 = tabel**4
    maxi = np.max(np.sum(tabel4, axis=1))
    sommen = list(np.sum(tabel4, axis=1))
    i = sommen.index(maxi)
    tabel[[0,i]] = tabel[[i,0]]    
    
    return tabel