import numpy as np

class Cirkel(object):
    def __init__(self, r, x, y):
        self.r = r
        self.x = x
        self.y = y
        
    def __str__(self):
        return "[%f (%f, %f)]" % (self.r, self.x, self.y)
        
    def __repr__(self):
        return "Cirkel(%r, %r, %r)" % (self.r, self.x, self.y)
        
    def __add__(self, tup):
        return Cirkel(self.r, self.x + tup[0], self.y + tup[1])
        
    def __radd__(self, tup):
        return self.__add__(tup)
        
    def __eq__(self, other):
        b1 = np.allclose(self.r, other.r)
        b2 = np.allclose(self.x, other.x)
        b3 = np.allclose(self.y, other.y)
        
        return (b1 and b2 and b3)
        
        