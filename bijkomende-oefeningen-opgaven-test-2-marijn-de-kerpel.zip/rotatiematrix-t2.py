import numpy as np
import math

def rotatiematrix(u, rotatiehoek):
    I = np.matrix(np.eye(3))
    U = np.matrix([[0, -u[2], u[1]],[u[2], 0, -u[0]],[-u[1], u[0], 0]])
    R = math.cos(rotatiehoek)*I + math.sin(rotatiehoek)*U + (1-math.cos(rotatiehoek))*u*u.T
    
    return R