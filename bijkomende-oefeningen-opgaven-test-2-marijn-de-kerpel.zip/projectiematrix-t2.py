import numpy as np

def projectiematrix(u):
    
    v = u/np.linalg.norm(u)
    I = np.eye(3)
    
    P = I - v*v.T
    
    return P