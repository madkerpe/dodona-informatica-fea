class Student(object):
    def __init__(self, naam, vakken=None, punten=None):
        self.naam = naam
        if vakken == None:
            self.vakken = []
        else:
            self.vakken = vakken
            
        if punten == None:
            self.punten = []
        else:
            self.punten = punten 
            
    def __str__(self):
        return "[%s:%d]" % (self.naam, len(self.vakken))
        
    def __repr__(self):
        return "Student(%r,%r)" % (self.naam, self.vakken)
        
    def __eq__(self, other):
        return self.naam == other.naam
        
    def __iadd__(self, tupple):
        vak = tupple[0]
        score = tupple[1]
        
        if vak in self.vakken:
            index = self.vakken.index(vak)
            self.punten.replace(score , index)
            
        else:
            self.vakken.append(vak)
            self.punten.append(score)
            
        return self
        
            
        
    def __call__(self, vak=None):
        if vak == None:
            return self.naam
        
        else:
            return self.punten[self.vakken.index(vak)]