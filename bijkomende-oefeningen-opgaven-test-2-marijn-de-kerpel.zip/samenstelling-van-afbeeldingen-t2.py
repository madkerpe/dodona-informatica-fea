def samenstelling(f, g):
    sam =  {}
    for key in g:
        uit_g = g.get(key, '?')
        uit_f = f.get(uit_g, '?')
        
        sam[key] = uit_f
        
    return sam
    
    