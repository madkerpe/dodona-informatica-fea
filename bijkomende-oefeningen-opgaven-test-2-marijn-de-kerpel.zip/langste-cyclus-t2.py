def max_cyclus(wb):
    n = len(wb)
    cyclussen = []    
    
    for i in range(1, n + 1):
        lengte_cyclus = 0
        eerste_keer = True
        e = -1
        
        while e != i:
            if eerste_keer:
                e = i
                eerste_keer = False
            e = wb[e]
            lengte_cyclus += 1
            
        cyclussen.append(lengte_cyclus)
        
    return max(cyclussen)
            
        

