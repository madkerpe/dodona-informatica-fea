import numpy as np

class Kassa(object):
    def __init__(self, naam, kassa_stand=None):
        self.naam = naam
        if kassa_stand == None:
            self.kassa_stand = []
        else:
            self.kassa_stand = list(kassa_stand)
            
    def get_positieve_transacties(self):
        kassa_stand = np.asarray(self.kassa_stand)
        return int(np.sum(kassa_stand > 0))
    
    def get_negatieve_transacties(self):
        kassa_stand = np.asarray(self.kassa_stand)  
        return int(np.sum(kassa_stand < 0))
        
    def __str__(self):
        return "[%s:%f]" % (self.naam, sum(self.kassa_stand))
        
        
    def __repr__(self):
        return "Kassa(%r, %r)" % (self.naam, self.kassa_stand)
        
    def __eq__(self, other):
        return self.naam == other.naam
        
    def __iadd__(self, bedrag):
        if sum(self.kassa_stand) + bedrag > 0:            
            self.kassa_stand.append(bedrag)
        return self
        
    def __isub__(self, bedrag):
        if sum(self.kassa_stand) - bedrag > 0:            
            self.kassa_stand.append(-bedrag)
        return self