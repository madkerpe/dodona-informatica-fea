import numpy as np
import math

class Driehoek(object):
    def __init__(self, A, B, C):
        self.A = A
        self.B = B
        self.C = C
        
    def __str__(self):
        return "[(%.2f,%.2f),(%.2f,%.2f),(%.2f,%.2f)]" % (self.A[0],self.A[1],self.B[0],self.B[1],self.C[0],self.C[1],)
        
    def __repr__(self):
        return "Driehoek(%r, %r, %r)" % (self.A, self.B, self.C)
        
    def __mul__(self, hoek):
        A = np.array([self.A[0], self.A[1]])
        B = np.array([self.B[0], self.B[1]])
        C = np.array([self.C[0], self.C[1]])
        
        
        R = np.array([[math.cos(hoek), -math.sin(hoek)],[math.sin(hoek), math.cos(hoek)]])
        
        Ax = float(np.dot(R, A)[0])
        Ay = float(np.dot(R, A)[1])
        Bx = float(np.dot(R, B)[0])
        By = float(np.dot(R, B)[1])
        Cx = float(np.dot(R, C)[0])
        Cy = float(np.dot(R, C)[1])
        
        return Driehoek((Ax,Ay),(Bx, By),(Cx, Cy))
        
    def __rmul__(hoek, self):
        return hoek.__mul__(self)
            
    def __eq__(self, other):
        
        b1 = np.allclose(self.A, other.A)
        b2 = np.allclose(self.B, other.B)
        b3 = np.allclose(self.C, other.C)
        return (b1 and b2 and b3)
        