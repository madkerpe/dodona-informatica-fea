def analyseer(woord):
    
    wb = {}
    
    paar_lijst = [woord[i:i+2] for i in range(len(woord) - 1)]
    
    hoofd_lijst = []
    for paar in paar_lijst:
        if paar[0] not in hoofd_lijst:
            hoofd_lijst.append(paar[0])
            
    for hoofd in hoofd_lijst:
        subwb = {}

        for paar in paar_lijst:
            if paar[0] == hoofd and paar[1] not in subwb:
                subwb[paar[1]] = paar_lijst.count(paar)
                
        wb[hoofd] = subwb
                
    return wb