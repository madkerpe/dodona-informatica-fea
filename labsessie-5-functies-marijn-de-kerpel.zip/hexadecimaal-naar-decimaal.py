def hex2dec(hexadecimale):
    decimale = int(hexadecimale, 16) #converts into an int from a string with base 16
    return decimale