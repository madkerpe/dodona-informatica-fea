import math

def wortel3(w):
    
    if w > 0:
        derde_wortel = w**(1.0/3.0)
    else:
        derde_wortel = abs(w)**(1.0/3.0)
        derde_wortel *= -1
    
    
    return derde_wortel


def cardano(a, b, c, d):
    p = float(((3*a*c)-b*b)/(3*a*a))
    q = float((2*b*b*b - (9*a*b*c) + 27*a*a*d)/(27*a*a*a))
    
    if (((q*q)/4) + ((p*p*p)/27)) > 0:
        u3 = (((-1*q)/2) + math.sqrt(((q*q)/4)+((p*p*p)/27)))
        v3 = (((-1*q)/2) - math.sqrt(((q*q)/4)+((p*p*p)/27)))
        
        
        
        return (wortel3(u3) + wortel3(v3))  - (b/(3*a))
    
    else:
        return 0.0