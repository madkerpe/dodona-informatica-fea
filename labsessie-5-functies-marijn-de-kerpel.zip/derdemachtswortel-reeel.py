def wortel3(a):
    
    if a > 0:
        derde_wortel = a**(1.0/3.0)
    else:
        derde_wortel = abs(a)**(1.0/3.0)
        derde_wortel *= -1
    
    
    return derde_wortel