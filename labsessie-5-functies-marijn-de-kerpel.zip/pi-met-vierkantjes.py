import math

def pie_vierkant(n):
    oppervlakte_vierkant = 2**2 
    aantal_vierkantjes = n**2
    lengte_vierkantje = 2/n
    oppervlakte_vierkantje = lengte_vierkantje**2
    straal_cirkel = 1
    x_midden = 1
    y_midden = 1
    x_punt = 0
    y_punt = 0
    aantal_in_cirkel = 0
    benadering_pie = 0
    
    for r in range(1,2*n,2):
        for k in range(1,2*n,2):
            
            if  n%2 == 0:
                x_punt = (k*2)/(2*n)#even aantal
                y_punt = (r*2)/(2*n)
            else:
                x_punt = (k*2)/(2*n) #oneven aantal
                y_punt = (r*2)/(2*n)
            
            
            afstand_tot_middelpunt =  math.sqrt(((x_punt - x_midden)**2) + ((y_punt - y_midden)**2))
            if afstand_tot_middelpunt < 1:
                aantal_in_cirkel += 1
                
            
            
    
    benadering_pie = aantal_in_cirkel*oppervlakte_vierkantje  
    return benadering_pie 
    