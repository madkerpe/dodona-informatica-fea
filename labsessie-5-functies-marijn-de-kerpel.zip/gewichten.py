def gewichten(massa_zwaar,massa_licht,aantal_zwaar,aantal_licht,gewenst):
    
    lijst_gewenst = []
    
    for a in range(aantal_zwaar + 1):  
        for b in range(aantal_licht + 1):    
            if  (a*massa_zwaar + b*massa_licht) == gewenst:
                correct_tuple = (a,b)
                lijst_gewenst.append(correct_tuple)
    
    
    
    return lijst_gewenst
    
    