

def driehoek(a,b,c):

    if a < 0 and b < 0 and c < 0 or a + b < c or a + c < b or b + c < a:
        return 0
    else:
        if abs(a-b) < 0.00001 and abs(a-c) < 0.00001 and abs(c-b) < 0.00001:
            return 3
        
        elif abs(a-b) < 0.00001 or abs(a-c) < 0.00001 or abs(c-b) < 0.00001:
            return 2
        
        else:
            return 1