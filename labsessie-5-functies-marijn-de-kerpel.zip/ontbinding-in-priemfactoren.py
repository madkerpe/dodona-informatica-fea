def ispriem(x):
    is_priem = 1
    i = 2
 
    while i < x:
        is_priem *= x%i 
        i += 1
    
    return (is_priem != 0 and x!= 1) 

def priemfactoren(n):
    factorlijst = []
    p = 2

    while n != 1:   
        if n%p == 0:
            factorlijst.append(p)    
            n /= p
        else:    
            p += 1
            while not ispriem(p):
                p += 1
    return factorlijst
        
    
    
 
print(priemfactoren(30))