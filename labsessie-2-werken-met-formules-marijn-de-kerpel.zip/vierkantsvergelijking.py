import math
import cmath

re_a = float(input())
im_a = float(input())
re_b = float(input())
im_b = float(input())
re_c = float(input())
im_c = float(input())

a = complex(re_a, im_a)
b = complex(re_b, im_b)
c = complex(re_c, im_c)

wortel_z1 = cmath.sqrt((b**2)-4*a*c) 
wortel_z2 = cmath.sqrt((b**2)-4*a*c) 


z1 = (-b + wortel_z1)/(2*a)
z2 = (-b - wortel_z2)/(2*a)

print(z1.real)
print(z1.imag)
print(z2.real)
print(z2.imag)
