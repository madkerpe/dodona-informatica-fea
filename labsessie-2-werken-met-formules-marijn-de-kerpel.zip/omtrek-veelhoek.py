import math

r = float(input())
n = float(input())

halve_hoek = float(((2*math.pi)/n)/2)
halve_lengte_zijde = float(math.sin(halve_hoek)*r)
lengte_zijde = float(halve_lengte_zijde*2)

omtrek = n*lengte_zijde

print(omtrek)
