import math

sk = float(input())
dk = float(input())
rv = float(input())
vj = 1.0

vj = math.ceil(math.log((dk/sk),(1 + (rv/100))))
vj = int((vj + abs(vj))/2)

print(vj)


