import math

re_z = float(input())
im_z = float(input())

z = complex(re_z, im_z)

p = abs(z)
q = math.atan2(z.imag, z.real)

print(p)
print(q)