import math

y = int(input())
N = int(input())
q = int(input())

#x = ((q*y)/((q*10**N) + 1))

x = math.floor(y/(10**N))



print(x)
print((x%q) == (y - (x*(10**N))))