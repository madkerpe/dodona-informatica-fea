import math

a = float(input())
D = float(input())

P = (D + a)/a
inverse_cosh = math.log(P + math.sqrt((P**2) - 1))
R = a*inverse_cosh


afstand_tussen_palen = 2*R



print(afstand_tussen_palen)
