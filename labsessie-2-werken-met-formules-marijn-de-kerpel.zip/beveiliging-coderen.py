x = int(input())
N = int(input())
q = int(input())

y = x*10**N + x%q
print(y)