x = int(input())

pos1 = x//2**8
a = x%2**8
pos2 = a//2**7
b = a%2**7
pos3 = b//2**6
c = b%2**6
pos4 = c//2**5
d = c%2**5
pos5 = d//2**4
e = d%2**4
pos6 = e//2**3
f = e%2**3
pos7 = f//2**2
g = f%2**2
pos8 = g//2**1
h = g%2

print(pos1*100000000 + pos2*10000000 + pos3*1000000 + pos4*100000 + pos5*10000 + pos6*1000 + pos7*100 + pos8*10 + h)
