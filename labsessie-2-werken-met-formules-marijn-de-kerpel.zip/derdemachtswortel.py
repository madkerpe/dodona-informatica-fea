import math

a = float(input())

r = a**(1/3.0)


print(r*math.cos(0))
print(r*math.sin(0))

k = 2
print(r*math.cos((2*math.pi)/3))
print(r*math.sin((2*math.pi)/3))

k = 3
print(r*math.cos((4*math.pi)/3))
print(r*math.sin((4*math.pi)/3))