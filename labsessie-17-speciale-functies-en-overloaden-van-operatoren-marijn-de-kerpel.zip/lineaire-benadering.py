class LineaireBenadering(object):
    def __init__(self, functie, a, h=1e-10):
        self.f = functie
        self.a = float(a)
        self.h = h
            
    def __call__(self, x):
    	
    	afgeleide = (self.f(self.a+self.h) - self.f(self.a))/self.h
    	
    	
    	return self.f(self.a) + afgeleide*(float(x)-self.a)