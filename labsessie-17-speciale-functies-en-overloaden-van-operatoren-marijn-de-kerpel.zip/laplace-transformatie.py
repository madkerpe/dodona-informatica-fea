import numpy as np
import math

def trapezium(g, a, b, n):    
	h = (b - a)/n    
	I = 0.5 * g(a)    
	for i in range(1, n):        
		I+= g(a + i*h)    
		I += 0.5*g(b)    
	I *= h    
	return I

class LaplaceTransformatie(object):
	
	def __init__(self, functie, R, n):
		self.functie = functie
		self.R = R
		self.n = n
		
	def __call__(self, s): 
		
		def te_int_functie(t):
			return math.exp(-s*t)*self.functie(t)

			
		return trapezium(te_int_functie, 0, self.R, self.n)