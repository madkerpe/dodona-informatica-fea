import numpy as np

class FysiekeGrootheid(object):

	def __init__(self, waarde, dimensie):
		self.waarde = waarde
		self.dimensie = dimensie
		
	def get_waarde(self):
		return self.waarde
	def get_dimensie(self):
		return self.dimensie
	def set_waarde(self, nieuwe_waarde):
		self.waarde = nieuwe_waarde
		
	def __str__(self):
		return "[%f %s]" % (self.waarde, self.dimensie)
	def __repr__(self):
		return "FysiekeGrootheid(%r, %r)" % (self.waarde, self.dimensie)
		
	def __add__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
		
		return FysiekeGrootheid(self.waarde + other.waarde, self.dimensie)
	def __sub__(self, other):
		if self.dimensie != other.dimensie:
			return "AttributeError"
		
		return FysiekeGrootheid(self.waarde - other.waarde, self.dimensie)
		
	def __pos__(self):
		return FysiekeGrootheid(self.waarde, self.dimensie)
	def __neg__(self):
		return FysiekeGrootheid((-1)*self.waarde, self.dimensie)
		
	def __eq__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
			
		return np.allclose(self.waarde, other.waarde)
	def __gt__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
			
		return self.waarde > other.waarde
	def __lt__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
		return self.waarde < other.waarde
	def __ne__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
			
		return not np.allclose(self.waarde, other.waarde)
	def __ge__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
			
		return self.waarde >= other.waarde
	def __le__(self, other):
		if self.dimensie != other.dimensie:
			raise AttributeError()
		return self.waarde <= other.waarde