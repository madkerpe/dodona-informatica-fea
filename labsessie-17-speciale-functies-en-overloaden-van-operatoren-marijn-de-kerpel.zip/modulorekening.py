###VERSEI VA NTHOMAS

import numpy as np
class Modulo(object):
  def __init__(self, grondtal, waarde=0):
    self.grondtal = grondtal
    self.waarde = (waarde%self.grondtal)
  def __str__(self):
    return '[%d %% %d]'%(self.waarde, self.grondtal)
  def __repr__(self):
    return 'Modulo(%r, %r)'%(self.grondtal, self.waarde)
  def __call__(self, waarde):
    return Modulo(self.grondtal, waarde%self.grondtal)
  def __add__(self, other):
    return Modulo(self.grondtal, self.waarde + other.waarde)
  def __sub__(self, other):
    return Modulo(self.grondtal, self.waarde - other.waarde)
  def __mul__(self, other):
    return Modulo(self.grondtal, (self.waarde * other.waarde))
  def __eq__(self, other):
    return self.grondtal == other.grondtal and self.waarde == other.waarde