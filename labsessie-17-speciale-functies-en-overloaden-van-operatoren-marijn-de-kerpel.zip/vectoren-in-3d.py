import math
import numpy as np

class Vector3D(object):
	
	def __init__(self, x, y, z):
		self.x = x
		self.y = y
		self.z = z
		self.vector = np.array([x, y, z])
		
	def get_x(self):
		return self.x
	def get_y(self):
		return self.y
	def get_z(self):
		return self.z
	
	def __add__(self, other):
		return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)	
	def __abs__(self):
		return math.sqrt(self.x**2 + self.y**2 + self.z**2)
	def __mul__(self, other):
		return self.x*other.x + self.y*other.y + self.z*other.z
	def __sub__(self, other):
		return Vector3D(self.x - other.x, self.y - other.y, self.z - other.z)
	def __matmul__(self, other):
		lijst = list(np.cross(self.vector, other.vector))
		return "[%.6f,%.6f,%.6f]" % (lijst[0], lijst[1], lijst[2])
	
	def __repr__(self):
		return 'Vector3D(%s,%s,%s)' % (str(self.x), str(self.y), str(self.z))
	def __str__(self):
		return '[%f,%f,%f]' % (self.x, self.y, self.z)