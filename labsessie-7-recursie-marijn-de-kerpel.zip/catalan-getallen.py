import math

def catalan(i):
    if i < 0:
        return -1
    elif i == 0:
        return 1
    
    else:
        return math.ceil((catalan(i-1))*(4*(i-1) + 2) // ((i-1) + 2))
        
    
    