def negatief(lijst, index=0):
    if index == len(lijst):
        return 0
    else:
        if lijst[index] < 0:
            return lijst[index]
        else:
            return negatief(lijst, index + 1)