def isPalindroom(woord, index=0):
    if index == len(woord)//2:
        return True
    else:
        if woord[index] == woord[-1*(index + 1)]:
            return isPalindroom(woord, index + 1)
            
        else:
            return False