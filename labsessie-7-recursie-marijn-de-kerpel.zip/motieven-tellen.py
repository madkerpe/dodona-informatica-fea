def telMotief(tekst, motief, index=0, aantal=0):
    
    if len(tekst) == 0:
        return 0
    
    elif index == len(tekst) - len(motief) + 1:
        return aantal
 
    else:
        if tekst[index:index + len(motief)] == motief:
            return telMotief(tekst, motief, index + 1, aantal +1)
        else:
            return telMotief(tekst, motief, index + 1, aantal)