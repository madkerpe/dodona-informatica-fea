def hakken(tekst, n, index=0):
    if index == len(tekst):
        return []
    
    else:
        if index%n == 0:
            return [tekst[index:index + n]] + hakken(tekst, n, index + 1)
            
        else:
            return hakken(tekst, n, index + 1)