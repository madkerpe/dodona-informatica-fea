def telKarakters(lijst, karakter, index=0, aantal=0):
    
    if index == len(lijst):
        return aantal
    else:
        if lijst[index] == karakter:
            return telKarakters(lijst, karakter, index + 1, aantal +1)
        else:
            return telKarakters(lijst, karakter, index + 1, aantal)