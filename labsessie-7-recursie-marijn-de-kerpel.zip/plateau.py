def plateau(l, p, i, element=None, aantal=0):
    
    if aantal >= p:
        return True
        
    
        
    if i < len(l):
        if element == l[i]:
            return plateau(l, p, i + 1, element, aantal + 1)
        
        if element is None:
            return plateau(l, p, i, l[i], 0)
    
    return False