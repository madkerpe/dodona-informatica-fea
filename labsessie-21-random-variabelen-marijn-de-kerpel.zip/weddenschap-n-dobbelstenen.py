###BROL VAN LOUIS

import numpy as np
def weddenschap(N,M,R,exp):
    x=list(np.random.randint(1,7,N*exp))
    winst=0.0
    for i in range(0,len(x),N):
        winst+=(sum(x[i:i+N])>=M)*R

        
    return (winst/exp) - 1