import random

def maak_stapel():
    kleur = ['harten', 'ruiten', 'schoppen', 'klaveren']
    waarde = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
    stapel = []
    for _ in kleur:
        for j in waarde:
            stapel.append(j)
    return stapel
    
def verschillende_waarde(M, exp):
        
    unieke_keuze = 0
    
    for _ in range(exp):
        stapel = maak_stapel()  
        random.shuffle(stapel)
        geen_dubbel = True
        keuze = stapel[0:M]
        for i in keuze:
            if keuze.count(i) != 1:
                geen_dubbel = False
        if geen_dubbel:
            unieke_keuze += 1
            
    return unieke_keuze/exp