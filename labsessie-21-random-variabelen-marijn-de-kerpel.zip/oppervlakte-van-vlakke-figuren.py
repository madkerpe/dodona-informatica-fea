import numpy as np

class Figuur(object):
    def __init__(self, xmin, xmax, ymin, ymax):
        self.xmin = xmin
        self.xmax = xmax
        self.ymin = ymin
        self.ymax = ymax
        
    def oppervlakte(self, aantal_punten):
        
        x_random = np.random.uniform(self.xmin, self.xmax, aantal_punten)
        y_random = np.random.uniform(self.ymin, self.ymax, aantal_punten)
        
        oppervlakte_rechthoek = (abs(self.xmin) + abs(self.xmax))*(abs(self.ymin) + abs(self.ymax))
        punten_in_figuur = sum(self.f(x_random, y_random)) 
        
        fractie = punten_in_figuur/aantal_punten
        
        return oppervlakte_rechthoek*fractie
        
        
class Cirkel(Figuur):
    
    def __init__(self, r):
        
        self.r = r        
        Figuur.__init__(self, -r, r, -r, r)
        
        
    def f(self, x, y):
        return x**2 + y**2 < self.r**2
        
class Ellips(Figuur):
    
    def __init__(self, a, b):
        
        self.a = a
        self.b = b
        Figuur.__init__(self, -a, a, -b, b)
        
    def f(self, x, y):
        return (x/self.a)**2 + (y/self.b)**2 < 1
        
        
    
        
    