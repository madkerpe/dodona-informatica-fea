import numpy as np
import math

def munten_sim(N, M, exp):
	worpen = np.random.randint(0, 2, N*exp)
	worpen = worpen.reshape(exp, N)
	
	
	aantal_kop = np.sum(worpen, axis=1)
	in_interval = np.sum(aantal_kop == M)
	
	return in_interval/exp
	
	
	
	
def munten_exact(N, M):
	breuk = 1/(2**N)
	combinatie = nCm(N, M)
	
	return breuk*combinatie
	
	
def nCm(N, M):
	top = math.factorial(N)
	bottom = math.factorial(N-M)*math.factorial(M)
	
	return top/bottom

np.random.seed(5)	
l_sim = [munten_sim(5, i, 10) for i in range(5 + 1)]

print(l_sim)