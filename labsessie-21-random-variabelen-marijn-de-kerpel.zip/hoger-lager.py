import random
import numpy as np
import math

class HogerLager(object):
    def __init__(self , a, b, max_beurten):
        self.a = a
        self.b = b
        self.max_beurten = max_beurten
        self.aantal_keer_geraden = 0        
        
    def speel(self, speler):
            
        geheim_getal = random.randint(self.a, self.b)
        poging = speler.eerste_poging(self.a, self.b)
        aantal_keer_geraden = 1
        
        while geheim_getal != poging and aantal_keer_geraden < self.max_beurten:
            
            if geheim_getal < poging:
                poging = speler.nieuwe_poging(1)
            
            else:
                poging = speler.nieuwe_poging(-1)
        
            aantal_keer_geraden += 1
        
        return aantal_keer_geraden
        
        



class SpelerDom():

    def eerste_poging(self, a, b):
        self.a = a
        self.b = b
        
        return random.randint(self.a, self.b)
    
    def nieuwe_poging(self, x):
        return random.randint(self.a, self.b)
        



class SpelerRandom(object):

    def eerste_poging(self, a, b):
        self.laatste_poging = random.randint(a, b)
        self.ondergrens = a
        self.bovengrens = b
        return self.laatste_poging
    
    def nieuwe_poging(self, x):
        if x == 1:
            self.bovengrens = self.laatste_poging - 1
        
        elif x == -1:
            self.ondergrens = self.laatste_poging + 1
            
        self.laatste_poging = random.randint(self.ondergrens, self.bovengrens)
        return self.laatste_poging
        
        
        
class SpelerSlim(object):

    def eerste_poging(self, a, b):
        self.ondergrens = a
        self.bovengrens = b
        self.laatste_poging = math.floor((self.ondergrens + self.bovengrens)/2)
        return self.laatste_poging
    
    def nieuwe_poging(self, x):
        if x == 1:
            self.bovengrens = self.laatste_poging - 1
        
        elif x == -1:
            self.ondergrens = self.laatste_poging + 1
            
        self.laatste_poging = math.floor((self.ondergrens + self.bovengrens)/2)
        return self.laatste_poging



def gemiddeld_aantal_beurten(HigherLower, Player, aantal_spelletjes):
    
    beurten = []    
    
    for _ in range(aantal_spelletjes):
        beurten.append(HigherLower.speel(Player))
        
    return np.mean(np.array(beurten))
        
        
    
    