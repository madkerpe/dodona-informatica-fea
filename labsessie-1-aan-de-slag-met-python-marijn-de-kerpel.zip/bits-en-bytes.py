mb = int(input())

print(mb*2**10)
print(mb*2**20)
print((mb*2**20)*2)
print((mb*2**20)*8)