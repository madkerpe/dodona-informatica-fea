k = float(input())
p = float(input())
l = float(input())

print(k*(((1+(p/100))**l)))