EXTRA NUMPY:

numpy.concatenate((a1, a2, ...), axis=0) #om meerdere aan elkaar te plaken
BIJ SLICEN KRIJG JE NOOIT EEN KOPIE BIJ RIJEN, WEL BIJ LIJSTEN

np.prod([[1.,2.],[3.,4.]], axis=1)
	#array([  2.,  12.])

#indexeren van rijen

a[[1,2,3]] = “kak” → zet de elementen met index 1, 2 en 3 om naar “kak”
a[a % 2 > 0] = 300 → zet de elementen die even zijn om naar 300

#Testen van rijen
	isinstance(a[0],float)
a[3][4] == a[3,4]


EXTRA:
a = [a, b, c, d]
b = [1, 2, 3, 4]
l = zip(a,b)

Closure = 
		- functie declareren binnen andere functie
		- geneste functie behoudt context van omhullende functie

def genereer_Y(a):    
	def Y(x):        
		return math.exp(a*x)    
	return Y

y2 = genereer_Y(2)
print(y2(5.0))
y10 = genereer_Y(10)
print(y10(5.0))



import decimal voor hoge precisie


Geformateerde Uitvoer:
	-H1: 11-13
	
Complexe:
	-H1: 39
	
Lambdify (functie omzetten naar een Python-functie):
	-H1: 43
	
Symbolisch oplossen zoals (bv: solve zoals in maple):
	-H1: 44-50
	
Invoegen in een lijst:
	p.insert(<pos>,<el>)

Niet in lijst:
	<waarde> not in lijst
	
Aliassen:
	"p is a" == "id(p) == id(a)"

Tuple 1 element:
	(1,)
	
Globale variabele in een functie:
	global <naam>
	<naam> = <waarde>
	
lambda:
	g = lambda <arg0>, <arg1>, <arg2>, … : <uitdrukking> 
	def g(<arg0>, <arg1>, <arg2>, … : 
	return <uitdrukking> 

Sprongen:
	break 	: spring uit de binnenste lus (voorbij de binnenste lus)
	continue	: spring naar volgende iteratie van de binnenste lus
	pass		: doe “niets” (place holder voor waar syntactisch een opdracht nodig is)

Exceptie afhandelen:
	try: 
		<opdrachten>
	except:
		<opdrachten>				# uitgevoerd in geval van excepties in try-blok

	H4: 33

Zelf excepties genereren
	H4: 37
	
Slicing bij rijen maakt geen kopie!!!!!!!!!

Rijen:
	np.array(r)				: maak nieuwe rij met zelfde inhoud als lijst r (kopie !)
	np.zeros(n)			: maakt rij van n lang, gevuld met 0.0 (float)
	np.zeros(n,t)			: idem maar rij-element is van type t
	np.linspace(p, q, n)		: nieuwe rij, n elementen gelijk verdeeld in [p,q] 						           		(grenzen inbegrepen !)
	np.concatenate((r0,r1,…)) 	: maak nieuwe array als aaneenschakeling van r0, r1, ...
	np.logical_and(x0,x1, ...)	: logische EN van argumenten
	np.logical_or(x0,x1, ...)	: logische OF van argumenten
	r[i:j:k]				: slicing (cf. lijst)
	
	Slicing bij rijen maakt geen kopie!!!!!!!!!
	
Functies plotten:
	H5: 7-18
	
Indexeren van rijen:
	rij[lijst] subrij met opgegeven indices
	
	[index] 			: rangnummer
	[a:b:i]   			: slice (indices a, a+i, a+2i, … tot b, b NIET ingebrepen)
	[lijst]    			: subrij met opgegeven indices
	[voorwaarde] 		: masking

Type van rijen:
	print(isinstance(a[0], float)) 		#True
	
	H5: 37
	
Functies op rijen:
	a.all()				: True indien alle elementen van a True zijn, anders False (logische EN)
	a.any()				: False indien alle emeneten van a False zijn, anders True (logische OF)
	np.dot(a,b)			: MATRIX-product op de rijen a en b
	np.sum(a) == a.sum() 	: som van alle elementen van a
	np.sum(a,axis=0) == a.sum(axis=0) : som over index 0 (analoog voor andere indices)
	np.max(a) == a.max()	: grootste element van a
	np.min(a) == a.min()	: kleinste element van a
	np.abs(a)	== a.abs()		: modulus van 
	np.random.uniform(a,b,shape)	: maakt een rij van opgegeven vorm, 
							   opgevuld met willekeurige getallen in [a,b[

itereren over tabellen:
	for (index,waarde) in np.ndenumerate(tabel):
			<verwerk element met index in tuple (i0,i1, ...,id)>

Matrices:
	np.matrix(lijst)	: maakt matrixversie van lijst (maakt kopie)
	np.matrix(array) : idem voor array (maakt kopie)
	m.shape		: vorm van de matrix
	np.eye(N)		: NxN eenheidsmatrix
	m.T			: nieuw matrix = getransponeerde van m
	a*b			: matrix-vermenigvuldiging
	a+b			: matrix-optelling			
	
Lineaire Algebra:
	np.linalg.inv(A)		: bereken inverse van A
	np.linalg.det(A)		: bereken determinant van A
	np.linalg.eig(A)		: eigenwaarden en eigenvectoren van A
	np.dot(A,B)		: matrixproduct (voor rijen !)
	np.transpose(A)		: getransponeerde van A (ook voor rijen !)
	np.linalg.norm(A)	: norm van A (= wortel uit som van modulus-kwadraat 
					van elementen van A) 
	a.T				: getransponeerde van a
	np.triu(a)			: bovendriehoek van a
	np.tril(a)			: onderdriehoek van a
	np.linalg.solve(A,b)	: zoek x uit Ax = b
	
Voorbeeld: inverse matrix
	import numpy as np
	a = np.matrix([[1, 2], [6, 3]])
	b = np.matrix([[9, 7], [-1, 5]])
	c = np.linalg.inv(a*b)
	ai = np.linalg.inv(a)
	bi = np.linalg.inv(b)
	print(c - bi*ai)
	print((a*b)*(bi*ai))

Voorbeeld: eigenwaarden
	import numpy as np
	a = np.matrix([[1, 2], [6, 3]])
	l, v = np.linalg.eig(a)
	print(l)
	print(v)
	print(a*v[:, 0]/v[:,0])
	print(a*v[:, 1]/v[:,1])
	
Rijen wisselen !!!

	H5: 55
	
	a = np.matrix(np.linspace(1, 25, 25).reshape(5, 5))
	a[1, 4] = a[4, 1] #wisselen elementen
		[[  1.   2.     3.    4.      5.] 
		[  6.   7.     8. 9. 22.] 
		[ 11.  12.  13.  14.  15.] 
		[ 16.  17.  18.  19.  20.] 
		[ 21.  22.  23.  24.  25.]]
		
	a[[1, 4]] = a[[4, 1]]
		[[  1.   2.     3.     4.     5.] 
		[ 21.  22.  23.  24.  25.] 
		[ 11.  12.  13.  14.  15.] 
		[ 16.  17.  18.  19.  20.] 
		[    6.    7.    8.    9.  10.]]
		
KOLOMMEN WISSELEN:
	a = np.matrix(np.linspace(1, 25, 25).reshape(5,5))
	a[np.ix_(range(5), [1,4])] = a[np.ix_(range(5), [4, 1])]
	
Dictionaries
	d.clear()              		maak dict leeg                        
	d.copy()                     	maak kopie van d (ondiep)             
	d[<key>]                     	indexering via sleutel                
	d.get(<key> ,default)    levert default op indien sleutel niet in d 
	d.keys()                     		levert alle sleutels van d            
	d.values()                   	levert alle waarden van d             
	d.items()                    	lijst van tuples (key, value) in d    
	d.setdefault(<key> , default) 	zet default voor sleutel expliciet 
	d.update(w)                  			voeg <key, values> uit woordenboek �							w aan d toe (of overschrijf) 
	d.update(l, w)               	idem als hierboven, maar itereer eerst over l�					(typisch lijst tuples) 
	len(d)                       		aantal elementen in d  (== len(d.keys()) 

Strings:
	s[start:end:step]		slice (substring, zelfde defaults als bij lijst)
	a in s				membership: True indien string a in s voorkomt
	s.find(a)			index van 1ste keer dat string a als deel van s voorkomt,�							resultaat -1 indien a niet in s voorkomt
	s.startswith(a)		True/False naargelang string a al dan niet aan de kop van s voorkomt
	s.endswith(a)		True/False naargelang string a al dan niet aan de kop van s voorkomt
	s.replace(<oud>,<nieuw>)	vervangt overal substring <oud> door <nieuw> in NIEUWE string
	s.lower()			Maak NIEUWE string met alle hoofdletters vervangen door kleine letters
	s.upper()			Maak NIEUWE string met alle kleine letters vervangen door hoofdletters
	s.isdigit()			True/False naargelang s enkel uit decimale cijfers bestaat
	s.isspace()			True/False naargelang s enkel uit “witte ruimte” bestaat 
					(geen zichtbare tekens bij afdrukken)
					
Functies op strings:
	s.strip()			NIEUWE string met witte ruimte aan kop en staart verwijderd
	s.lstrip()			NIEUWE string met witte ruimte aan kop verwijderd
	s.rstrip()			NIEUWE string met witte ruimte aan staart verwijderd
	s.split([<sep>])			opsplitsen van string s in stukjes (in lijst)
	s.join(<itereerbaar object>] nieuwe string, alle objecten uit argument, lijst van strings, 					                    gescheiden door string s

	==				vergelijken van string-inhoud
	s + t				concatenatie van s en t
	s*n				n keer de string s
	
Offline Webpagina's:
	import urllib.request
	url = 'http://www.ugent.be'
	urllib.request.urlretrieve(url, filename = 'UGent.html')
	
	# verwerk bestand
	with open('UGent.html', 'r', encoding = 'utf-8') as infile:
		for line in infile:
			print(line)
			
Online Webpagina's:
	import urllib.request
	url = 'http://www.ugent.be’

	with urllib.request.urlopen(url) as infile:
		for line in infile:
			print(line)
			
Inlezen van CSV-bestanden: rij per rij
	import csv
		with open(bestandsnaam, 'r') as infile:
			for rij in csv.reader(infile, delimiter = ';'):
				# verwerk rij
				
Inlezen van CSV-bestanden: volledig
	import csv
		with open(bestandsnaam, 'r') as infile:
			tabel = [rij for rij in csv.reader(infile, delimiter = ';')]
			
schrijven van CSV-bestanden:
	with open(bestandsnaam, ’w’) as outfile:
		writer = csv.writer(outfile, delimiter = ’;’)
		for rij in tabel:
			writer.writerow(rij)
			
Lezen uit een bestand zonder context: regel per regel
	<varnaam> = open(<bestandsnaam>, 'r')
		for line in <varnaam> :
			# verwerk de regel in line
	<varnaam>.close() #afsluiten bestand

Lezen uit een bestand met context: regel per regel
	with open(<bestandsnaam>, ’r’) as <varnaam>:
		for line in <varnaam>:
			# verwerk de regel in line
			
Lezen uit een bestand zonder context: volledig
	<varnaam> = open(<bestandsnaam>, ’r’)
	lines = <varnaam>.readlines() # lines = lijst van alle regels
	<varnaam>.close() #afsluiten bestand
	#verwerk lines

Lezen uit een bestand via context: volledig
	with open(<bestandsnaam>, ’r’) as <varnaam>:
		lines = <varnaam>.readlines()
		#verwerk lines
		
Schrijven naar een bestand zonder context:
	<varnaam> = open(<bestandsnaam>, ’w’) # ’a’ i.p.v. ’w’ om bij te schrijven
	<varnaam>.write(<string>) # schrijf string via write-functie
	<varnaam>.close()
	
Schrijven naar een bestand via context:
	with open(<bestandsnaam>, ’w’) as <varnaam>:
		<varnaam>.write(<stringuitdrukking>)


Klassen:

	object.__dict__ ##ja ZONDER haakjes
	
Propreties:
	<property_naam> = property(<getter_methode>, <setter_methode>
						<del_methode>, <doc string>)

Callable classes:
	__call__([args])	: wordt automatisch opgeroepen bij <obj>([args])
	callable(<obj>)		: True/False naargelang <obj> callable is
	
Operator Overloading:

	a == b								a.__eq__(b)
	a > b									a.__gt__(b)
	a >= b								a.__ge__(b)
	a < b									a.__lt__(b)
	a <= b								a.__le__(b)
	a != b								a.__ne__(b)

	-a									a.__neg__()
	+a									a.__pos__()
	len(a)								a.__len__()
	abs(a)								a.__abs__()

	int(a)									a.__int__()
	long(a)								a.__long__()
	float(a)								a.__float__()
	complex(a)								a.__complex__()
	bool(a)								a.__bool__()

	oct(a)								a.__oct__()
	hex(a)								a.__hex__()
	
	bool(obj) wordt automatisch opgeroepen bij

	if obj:
		…

	Indien obj.__bool__() bestaat -> resultaat wordt gebruikt
	Indien niet : obj.__len__() in de plaats (is altijd gedefinieerd)
	
Gemengde uitdrukkingen:
	Optie 1: typeconversie naar Complex
		def __add__(self, other):       
			if isinstance(other, (int, float)):  
				other = Complex(other)        
		return Complex(self.re + other.re, self.im + other.im)

	Optie 2: verschillende versies van ‘+', DUCKTYPING:
		if isinstance(other, (int, float)):            
		elif hasattr(other, 're') and hasattr(other, 'im'):     

Right operations		
	a + b									b.__radd__(a)
	a – b									b.__rsub__(a)
	a*b									b.__rmul__(a)
	a/b									b.__rtruediv__(a) #rdiv in Python 2.7
	a//b									b.__rfloordiv__(a)
	a%b									b.__rmod__(a)
	a**b								b.__rpow__(a)
	
In-place- operatoren:
	a += b								a.__iadd__(b)
	a –= b								a.__isub__(b)
	a*=b								a.__imul__(b)
	a/=b									a.__itruediv__(b) #idiv in Python 2.7
	a//=b								a.__ifloordiv__(b)
	a%=b								a.__imod__(b)
	a**=b								a.__ipow__(b)

Module random
	random.random()			willekeurig reëel getal in [0, 1[, uniform verdeeld
	random.uniform(a, b)		willekeurig reëel getal in [a, b[, uniform verdeeld
	random.normalvariate(m, s)  willekeurig reëel getal, normaal verdeeld N(m, s)
	random.seed(int)			initialiseer random generator met dit geheel getal

Gevectoriseerde random
	np.random.random()			1 willekeurig reëel getal in [0, 1[, uniform verdeeld
	np.random.random(size = N)	rij van N willekeurige reële getallen in [0, 1[, uniform verdeeld
	np.random.uniform(a, b)		1 willekeurig reëel getal in [a, b[, uniform verdeeld
	np.random.uniform(a, b, size = N) rij van N willekeurige reële getallen in [a, b[, uniform verdeeld 	
	np.random.normal(m, s, size = N) rij van N willekeurige reële getallen, normaal verdeeld N(m, s)
	np.random.randn(N)			idem, maar N(0, 1)
	np.random.seed(int)			initialiseer random generator met dit geheel getal
	
	
	np.mean(rij)				bereken gemiddelde van de rij
	np.std(rij)					bereken standaardafwijking van de rij

Histogram:
	H8: 5
	
Random Walk: enkel deeltje
	def random_walk_1(n):    
	x = [0]    for i in range(n):        
		m = random.randint(0, 1)        
			if m == 0:            
				x.append(x[-1] + 1)        
			else:            
				x.append(x[-1] - 1)    
	return x
	
Random Walk: n deeltjes
	def random_walk_v(nd, ns):    
		moves = 2*np.random.randint(0, 2, nd*ns) – 1
		moves.shape = (ns, nd)
		x = np.zeros(nd)    
		for i in range(ns):        
			x = x + moves[i, :]    
		return x

