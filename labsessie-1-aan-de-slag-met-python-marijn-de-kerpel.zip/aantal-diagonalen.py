n = int(input())

print(int(n*(n-3)/2))