m = int(input())
n = int(input())

a = int(m**2 - n**2)
b = int(2*m*n)
c = int(m**2 + n**2)

print(a)
print(b)
print(c)