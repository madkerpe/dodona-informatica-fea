a = float(input())
b = float(input())
c = float(input())
x = float(input())

print(a*x**2 + b*x + c) 