def applyAll(lf,x):
    r = []
    for i in lf:
        r.append(i(x))
    return r
    