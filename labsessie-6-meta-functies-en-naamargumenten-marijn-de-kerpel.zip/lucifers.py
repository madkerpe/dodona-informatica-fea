def lucifers(f, g, n, m):
    pot = n
    beurtenlijst = []
    beurtenlijst.append(pot)
    
    while n > 0:
        if f(n,m) > m or n - f(n,m) <= 0:
            winnaar = 1
            break
        n -= f(n,m)
        beurtenlijst.append(n)
        
        if g(n,m) > m or n - g(n,m) <= 0:
            winnaar = 0
            break
        n -= g(n,m)
        beurtenlijst.append(n)
        
        
    return (beurtenlijst, winnaar)
    
    