def volume(p=101300, n=1,T=293.15):
    R = 8.3144598
    V = (n*R*T)/p
    return V