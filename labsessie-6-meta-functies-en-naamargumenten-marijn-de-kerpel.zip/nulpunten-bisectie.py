def bisectie(f, a, b, tol=1E-6, maxIter=10):
    c = (a+b)/2
    i = 1
    
    while (i < maxIter or maxIter == 0) and abs(f(c)) > tol:
            
        
        if f(c)*f(a) < 0:
            b = c
        else:
            a = c
        
        c = (a+b)/2
        i += 1
               
    
    
    nulpunt = c
    return nulpunt