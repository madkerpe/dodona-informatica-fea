import math

def f0(f, x):
    return f(x)

def f1(f, x, h=0.01):
    return (f(x+h)-f(x-h))/(2*h)
    
def f2(f, x, h=0.01):
    return (f(x-h)-2*f(x)+f(x+h))/(h**2)

def f3(f, x, h=0.01):
    return (-1*f(x-2*h)+2*f(x-h)-2*f(x+h)+f(x+2*h))/(2*h**3)

def taylor(f, x, h=0.01):
    colijst = []
    
    colijst.append(f0(f,x)/math.factorial(0))
    colijst.append(f1(f,x)/math.factorial(1))
    colijst.append(f2(f,x)/math.factorial(2))
    colijst.append(f3(f,x)/math.factorial(3))
    
    
    
    
    return colijst