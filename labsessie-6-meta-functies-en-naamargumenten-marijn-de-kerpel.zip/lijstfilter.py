def filter(f,l):
    r = []   
    for i in l:
        if f(i):
            r.append(i)
    return r