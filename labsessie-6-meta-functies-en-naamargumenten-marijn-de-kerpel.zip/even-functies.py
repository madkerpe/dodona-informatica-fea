def isEven(f, arg = [1, 2, 3, 4, 5]):
    
    evenheid = 1
    
    for i in arg:
        if abs(f(i) - f(-i)) < 0.00001:
            evenheid += 1
        else:
            evenheid *= 0
    
    return evenheid > 0 