def multi_split(strings, seperators):
    
    if len(seperators) == 0:
        return strings
    
    bewerkte_strings = []
    for string in strings:
        for stukje in string.split(seperators[0]):
            bewerkte_strings.append(stukje)
    
    for _ in range(bewerkte_strings.count('')):
        bewerkte_strings.remove('')
    
            
    
    return multi_split(bewerkte_strings, seperators[1:])