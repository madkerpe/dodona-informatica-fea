def lijst(w):
	
	oplossing_lijst = []
	for i in range(max([keys for keys in w]) + 1):
		oplossing_lijst.append(float(w.get(i, 0.0)))
	
	return oplossing_lijst

def som(v, w, tol=1e-10):
	for key in v: 
		w[key] = float(w.get(key, 0.0) + v[key])
	
	w = {key:float(w[key]) for key in w if abs(w[key]) > tol}
	
	return w
	
def product(v, w, tol=1e-10):
	prod = {}
	for key_v in v:
		for key_w in w:
			prod[key_v + key_w] = w[key_w]*v[key_v] + prod.get(key_v + key_w, 0.0)
	
	prod = {key:float(prod[key]) for key in prod if abs(prod[key]) > tol}
	
	return prod