import csv

def multi_split(strings, seperators):
    
    if len(seperators) == 0:
        return strings
    
    bewerkte_strings = []
    for string in strings:
        for stukje in string.split(seperators[0]):
            bewerkte_strings.append(stukje)
    
    for _ in range(bewerkte_strings.count('')):
        bewerkte_strings.remove('')
    
            
    
    return multi_split(bewerkte_strings, seperators[1:])

def frequentietabel(bestandsnaam):
    
    boek = {}
    
    with open(bestandsnaam, 'r') as infile:
        for rij in csv.reader(infile, delimiter = ';'):
            for symbool in ['{', '}', '[', ']', '(', ')', '+', '=', '-', '*', '0', '1', '2', '3', '4','5', '6', '7', '8', '9']:
                rij = [element.replace(symbool, ' ') for element in rij]
            
            rij = multi_split(rij, [',', '.', ';', ' ', ':', '!', '?', '\n'])
            rij = [element.strip().lower() for element in rij]
            
            for woord in rij:
                if woord in boek:
                    boek[woord] = boek[woord] + 1
                else:
                    boek[woord] = 1
                    
    return boek
            
            
            
    

            
    
