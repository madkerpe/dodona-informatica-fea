def inverteer(w):
	iw = {}

	for key in w:
		iw[w[key]] = iw.get(w[key], [])
		iw[w[key]].append(key)
		
	for key in iw:
		if len(iw[key]) == 1:
			iw[key] = iw[key][0]
		else:
			iw[key] = sorted(iw[key])
		
	return iw