def parse_query(url):
	
	w = {}
	wargs = {}
	
	#locatie
	locatie = (url.split('?'))[0]
	
	w["locatie"] = locatie
	
	#query
	query = url.split('#')[1]
	query = query[2:]
	query = query.replace("+"," ")
	
	w["query"] = query
	
	#sleute-waardenpaar
	sl_w = (url.split('#')[0]).split('?')[1]
	sl_w = sl_w.split('&')
	wargs = {paar.split('=')[0]:paar.split('=')[1] for paar in sl_w}
	w["args"] = wargs
	
	return w