#from collections import defaultdict


def codeer(w,s):
	#g = defaultdict(lambda: e)
	#g.update(w)
	nieuwe_s = ''
	
	for e in s:
		nieuwe_s +=  w.get(e, e)
	
	return nieuwe_s
	
def decodeer(w,s):
	omgekeerde_w = {w[key]:key for key in w} 
	nieuwe_s = ''
	
	for e in s:
		nieuwe_s +=  omgekeerde_w.get(e, e)

	return nieuwe_s