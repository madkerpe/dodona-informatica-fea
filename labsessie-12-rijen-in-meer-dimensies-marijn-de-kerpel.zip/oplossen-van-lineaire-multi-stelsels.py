import numpy as np

def gauss_piv(a):
    rank = 0
    m, n = a.shape
    i = 0
    for j in range(n):
        p = np.argmax(abs(a[i:m, j]))
        if p > 0:
                a[[i,p+i]] = a[[p+i, i]]
        if a[i,j] != 0:
                rank += 1
                for r in range(i + 1, m):
                    a[r, j:] -= (a[r, j]/a[i, j])*a[i, j:]
                i += 1
        if i >= m:
                break
    return a, rank
def solve(A, b):
    
    M = A.shape[0]
    b = np.asarray(b)
    matrix = np.append(A, b, axis=1)
    
    grote_matrix = gauss_piv(matrix)[0]
    rank_grote_matrix = gauss_piv(matrix)[1] 
    oplossingen_lijst = []
    
    if rank_grote_matrix != M:
        return np.zeros((rank_grote_matrix,1))
        
    C = grote_matrix[0:M, 0:M]
    d = grote_matrix[:, M:]
    
    #Toevoeging eerste oplossing
    eerste_oplossing = d[M - 1]/C[M - 1, M - 1]
    oplossingen_lijst.append(eerste_oplossing)
    
    #Toevoeging van de rest
    for i in range(M - 1):
        j = M - 2 - i #inverse_i
        tussen_oplossing = ((d[j] - np.dot(C[j][j + 1 :M], oplossingen_lijst[::-1])) / (C[j, j]))
        oplossingen_lijst.append(tussen_oplossing)
    
    return np.array(oplossingen_lijst[::-1])
def solve_multi(A, B):
	
	M, N = B.shape 
	array_oplossingen = solve(A, B[:,[0]])

	for i in range(1,N):
		array_oplossingen = np.append(array_oplossingen, solve(A, B[:,[i]]), axis=1)
	
	return array_oplossingen
def inv(A):
	
	#contructie eenheidsmatrix
	B = np.eye(len(A))
	
	return solve_multi(A, B)