import numpy as np

def score(a, b):
	fouten = 0
	for i, e in np.ndenumerate(a):
		if e + b[i] == 0:
			fouten += 1
	return fouten

def volgende(a, b):
	m, n = a.shape
	originele_score = score(a, b)
	
	score_rij_lijst = []
	bewerking_rij_lijst = []

	score_kolom_lijst = []
	bewerking_kolom_lijst = []

	for i in range(m):
		a[i] *= (-1)
		score_rij_lijst.append(score(a, b))
		bewerking_rij_lijst.append(i)
		a[i] *= (-1)
		#print(score_rij_lijst)
		#print(bewerking_rij_lijst)
		
	mini_rij_score = min(score_rij_lijst)
	mini_rij_bewerking = bewerking_rij_lijst[score_rij_lijst.index(mini_rij_score)]
	
	#print(mini_rij_score)
	#print(mini_rij_bewerking)
	
	for i in range(n):
		a[:,i] *= (-1)
		score_kolom_lijst.append(score(a, b))
		bewerking_kolom_lijst.append(i)
		a[:,i] *= (-1)
		#print(score_kolom_lijst)
		#print(bewerking_kolom_lijst)
		
	mini_kolom_score = min(score_kolom_lijst)
	mini_kolom_bewerking = bewerking_kolom_lijst[score_kolom_lijst.index(mini_kolom_score)]
	
	#print(mini_kolom_score)
	#print(mini_kolom_bewerking)
	
	#score_lijst = score_rij_lijst + score_kolom_lijst
	#bewerkingen_lijst = bewerking_rij_lijst + bewerking_kolom_lijst
	
	if mini_rij_score <= mini_kolom_score and mini_rij_score < originele_score:
		a[mini_rij_bewerking] *= (-1)
		return (a, mini_rij_score)
		
	elif mini_kolom_score < mini_rij_score and mini_kolom_score < originele_score:
		a[:,mini_kolom_bewerking] *= (-1)
		return (a, mini_kolom_score)
		
	else:
		return (a, originele_score)

def losOp(a, b):
	temp_score = score(a, b)
	#nieuwe_score = volgende(a, b)[1]
	temp_a = volgende(a,b)[0]
	
	while temp_score > volgende(temp_a, b)[1]:
		temp_score = score(temp_a, b)
		temp_a = volgende(temp_a, b)[0]
		
	return temp_a