import numpy as np

def schat(matrix, m, n):    
    M, N = matrix.shape
    max_som = 0    
    max_positie = (M, N)
    temp_som = 0
    temp_positie = (0, 0)    
    
    
    for i in range(M-m+1):
        for j in range(N-n+1):
            temp_som = np.sum(matrix[i:i + m, j:j + n])
            temp_positie = (i, j)
            if temp_som > max_som or (temp_som == max_som and max_positie[0] > temp_positie[0]):
                max_som = temp_som
                max_positie = temp_positie                    
            
    return max_positie