import numpy as np

def som_rij_kolom(originele_matrix):
    
    m, n = originele_matrix.shape
    nieuwe_matrix = np.zeros((m + 1)*(n + 1)).reshape(m + 1, n + 1)
    
    for i, e in np.ndenumerate(originele_matrix):
        nieuwe_matrix[i[0], i[1]] = e

    som_rijen = np.sum(originele_matrix, axis=1)
    for i in range(m):
        nieuwe_matrix[i, n] = som_rijen[i]
    
    
    som_kolommen = np.sum(nieuwe_matrix, axis=0)
    for i in range(n + 1):
        nieuwe_matrix[m, i] = som_kolommen[i]          
        
        
    return nieuwe_matrix
    
    
    