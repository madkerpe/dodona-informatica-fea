import numpy as np

def gauss_piv(tabel):
    rang = 0
    M, N = tabel.shape
        
    for verdieping in range(M):
        if tabel[verdieping, verdieping] != 0:
            tabel[verdieping] /= tabel[verdieping, verdieping]
            for rij in range(verdieping + 1, M): 
                tabel[rij] -= tabel[verdieping]*tabel[rij,verdieping]
    
    
    for i, _ in np.ndenumerate(tabel):
        if np.allclose(tabel[i], 0):
            tabel[i] = 0
            
    return tabel, rang
def solve(A, b):
    
    M = A.shape[0]
    b = np.asarray(b)
    matrix = np.append(A, b, axis=1)
    
    grote_matrix = gauss_piv(matrix)[0]
    rank_grote_matrix = gauss_piv(matrix)[1] 
    oplossingen_lijst = []
    
    if rank_grote_matrix != M:
        return np.zeros((rank_grote_matrix,1))
        
    C = grote_matrix[0:M, 0:M]
    d = grote_matrix[:, M:]
    
    #Toevoeging eerste oplossing
    eerste_oplossing = d[M - 1]/C[M - 1, M - 1]
    oplossingen_lijst.append(eerste_oplossing)
    
    #Toevoeging van de rest
    for i in range(M - 1):
        j = M - 2 - i #inverse_i
        tussen_oplossing = ((d[j] - np.dot(C[j][j + 1 :M], oplossingen_lijst[::-1])) / (C[j, j]))
        oplossingen_lijst.append(tussen_oplossing)
    
    return np.array(oplossingen_lijst[::-1])