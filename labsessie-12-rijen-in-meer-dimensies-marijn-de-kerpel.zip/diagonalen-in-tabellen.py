import numpy as np

def diag_tabel(N):
    rij = np.arange(1, N + 1)
    matrix = np.zeros(N*N).reshape((N, N)).astype(int) # of  matrix = np.zeros((N*N), int)
    for i, e in np.ndenumerate(matrix):
    	verschil = abs(i[0]-i[1])
    	matrix[i] = int(verschil + 1)
    		
    return matrix