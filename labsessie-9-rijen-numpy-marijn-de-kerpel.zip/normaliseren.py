import numpy as np

def normaliseer(rij):
    factor = 1/np.max(np.abs(rij))  #zet np er bij voor efficientere berekening
    return rij*factor