import numpy as np

def kwadraat(el):
    return el*el



def regressie(x, y):
    
    m_x = np.mean(x)
    m_y = np.mean(y)
    
    
    teller_termen = (x-m_x)*(y-m_y)
    noemer_termen = kwadraat((x - m_x))
    
    teller = np.sum(teller_termen)
    noemer = np.sum(noemer_termen)
    
    
    a = teller/noemer
    b = m_y - a*m_x
    
    return (a, b)
    
    