import math
import numpy as np


def gauss(x, mu, sigma):
    np.asarray(x)
    
    result = (1/(math.sqrt(2*math.pi)*sigma))*np.exp(-((x - mu)**2)/(2*sigma**2)) #moet np.exp() gebruiken want het slaat op een array en NIET op een scalair zoals bij de andere gebruiken in dit programme van math....
    
    return result