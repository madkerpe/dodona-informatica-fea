import numpy as np

def voortGem(rij, N):
	
	res = np.zeros(len(rij))
	rij = np.asarray(rij)
	
	for i in range(len(rij)):

		if i < N:
			res[i] = (1/(i+1))*np.sum(rij[0:i+1])
				
		else:
			res[i] = (1/N)*np.sum(rij[i-N+1:i+1])
			
	return res