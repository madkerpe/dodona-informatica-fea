import numpy as np

def trapezium(f, a, b, N):
    
    delta = (b-a)/N
    term = (f(a) + f(b))/2
    elementen = np.ones(N)[1:]*a + np.arange(N)[1:]*delta
    som = np.sum(f(elementen))
    
    
    integraal = delta*(term + som)
    
    return integraal