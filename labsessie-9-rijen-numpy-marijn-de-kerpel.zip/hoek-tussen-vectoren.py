import math
import numpy as np

def kwadraat(x):
    return x*x


def hoek(u, v):
    if len(u) == len(v):
        
        cos_teller = np.sum(u*v)
        
        kwadraatrij_u = np.sqrt(np.sum(kwadraat(u)))
        kwadraatrij_v = np.sqrt(np.sum(kwadraat(v)))
        cos_noemer = kwadraatrij_u * kwadraatrij_v
        
        return math.acos(cos_teller/cos_noemer)
    
    else:
        return float(-1.0)