def dichtsteBuur(x, v):
    termen = x - np.ones(len(x))*v
    
    return np.argmin(np.abs(termen))