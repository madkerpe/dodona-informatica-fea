import numpy as np
class Vakscore(object):
    def __init__(self, naam, maxscore=20):
        self.naam = str(naam)
        self.maxscore = int(maxscore)
        self.score = []
    def get_naam(self):
        return self.naam
    def voeg_toe(self, punt):
        if 0 <= punt <= self.maxscore:
            self.score.append(punt)
            return True
        else:
            return False
    def get_score(self):
        return self.score
    def gemiddelde(self):
        m = np.array(self.score)
        gem = np.mean(m)
        return gem
    def aantal_ABC(self):
        l = [0, 0, 0]
        for i in self.score:
            if i >= ((self.maxscore/10) * 6):
                l[0] += 1
            elif i < (self.maxscore/2):
                l[2] += 1
            else:
                l[1] += 1
        return l