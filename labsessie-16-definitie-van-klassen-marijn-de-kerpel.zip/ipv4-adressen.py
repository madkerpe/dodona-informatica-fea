class InternetAdres(object):

    def __init__(self, x1, x2, x3, x4):
        self.x1 = x1
        self.x2 = x2
        self.x3 = x3
        self.x4 = x4
        self.adres = [x1, x2, x3, x4]
        
    def get_adres(self):
        return self.adres
        
    def get_klasse(self):      
        
        if self.x1 < 128:
            return 'A'
            
        elif self.x1 >= 240:
            return 'E'
            
        elif self.x1 >= 128 and self.x1 <= 191: #Y160
            return 'B'
            
        elif self.x1 >= 192 and self.x1 <= 223:
            return 'C'
            
        else:
            return 'D'