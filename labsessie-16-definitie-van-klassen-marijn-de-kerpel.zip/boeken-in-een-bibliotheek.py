class Boek(object):
	def __init__(self, titel, cata, auteur):
		self.titel = titel
		self.cata = cata
		self.auteur = auteur
		self.uitgeleend = False
		self.uitleenaantal = 0
		
	def ontleen(self):
		if self.uitgeleend:
			
			return False
		else: 
			self.uitleenaantal += 1
			self.uitgeleend = True
			return True
		
		return self.uitgeleend
	
	def breng_terug(self):
		if self.uitgeleend:
			self.uitgeleend = False
			return True
		else:
			return False
		
		
	def is_uitgeleend(self):
		return self.uitgeleend
		
	##getters en setters
	
	def get_titel(self):
		return self.titel
		
		
	def set_titel(self, nieuwe_titel):
		self.titel = nieuwe_titel	
	
	
	def get_auteur(self):
		return self.auteur
		
	
	def set_auteur(self, nieuwe_auteur):
		self.auteur = nieuwe_auteur
	
	
	def get_catalogusnummer(self):
		return self.cata
		
		
	def set_catalogusnummer(self, nieuwe_cata):
		
		self.cata = nieuwe_cata
		
		
	def get_aantal_ontleningen(self):
		
		return self.uitleenaantal