import numpy as np

class LagrangePolynoom(object):
    def __init__(self, lijst):
        self.lijst = lijst
        self.N = len(lijst)
    
    def value(self, x):
        som = 0    
        for i in range(self.N):           
            som += self.lijst[i][1]*self.Li(x, i)
        
        return som
        
    def Li(self, x, i):
        product = 1
        for j in range(self.N):
            if i != j:
                product *= (x-self.lijst[j][0])/(self.lijst[i][0]-self.lijst[j][0])
            
        return product