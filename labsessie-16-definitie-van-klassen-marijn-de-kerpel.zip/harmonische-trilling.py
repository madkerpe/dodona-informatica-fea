import math

class HarmonischeTrilling(object):
    def __init__(self, A, w, o):
        self.A = A
        self.w = w
        self.o = o
    
    def value(self, t):
        return self.A*math.cos(self.w*t + self.o)