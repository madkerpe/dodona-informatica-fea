class Persoon(object):
    def __init__(self, voornaam, familienaam, geslacht, geboortejaar):
        self._voornaam = voornaam
        self._familienaam = familienaam
        self._geboortejaar = geboortejaar
        self._geslacht = geslacht
    def __str__(self):
        return '(' + self._voornaam + ' ' + self._familienaam + '[' + str(self._geboortejaar) + ',' + self._geslacht +'])'
    def set_voornaam(self, nieuwe_voornaam):
        self._voornaam = nieuwe_voornaam
    def get_voornaam(self):
        return self._voornaam
    def set_familienaam(self, nieuwe_familienaam):
        self._familienaam = nieuwe_familienaam
    def get_familienaam(self):
        return self._familienaam
    def set_geboortejaar(self, geb):
        self._geboortejaar = geb
    def get_geboortejaar(self):
        return self.geboortejaar
    def set_geslacht(self, g):
        if g == 'm'or g == 'v':
            self._geslacht = g
    def get_geslacht(self):
        return self._geslacht
    voornaam = property(get_voornaam, set_voornaam, None, None)
    familienaam = property(get_familienaam, set_familienaam, None, None)
    geslacht = property(get_geslacht, set_geslacht, None, None)
    geboortejaar = property(get_geboortejaar, set_geboortejaar, None, None)
    
class Voertuig(object):
	def __init__(self, merk, serienummer):
		self.merk = merk
		self.serienummer = serienummer
		
	def __str__(self):
		return "[%s:%s]" % (self.merk, self.serienummer)
		
	def __eq__(self, other):
		return self.__dict__ == other.__dict__
		
class VoertuigEigenaar(Persoon):
	
	def __init__(self, voornaam, familienaam, geslacht, geboortejaar, lijst=None):
		Persoon.__init__(self, voornaam, familienaam, geslacht, geboortejaar)
		self.lijst = [] if lijst == None else lijst

	
	def __iadd__(self, other):
		
		if not other in self.lijst:
			self.lijst.append(other)
		
		return self
		
	def __isub__(self, other):
		
		if other in self.lijst:
			self.lijst.remove(other)
		
		return self
		
	def __str__(self):
		
		return "%s:[%s]" % (super(VoertuigEigenaar, self).__str__(), ','.join([str(i) for i in self.lijst]))