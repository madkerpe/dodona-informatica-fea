def aantal_medeklinkers(woord): 
    klinker_lijst = ['a','e','i','o','u', 'y','A','E','I','O','U']
    aantal_medeklinkers = len(woord)    
    if woord.isalpha():
        for letter in woord:
            if letter in klinker_lijst:
                aantal_medeklinkers -= 1
        
        return aantal_medeklinkers
    return 0
    
def index_meeste_medeklinkers(lijst):
    maxi = max([aantal_medeklinkers(woord) for woord in lijst])
    
    mogelijke_indexen = []
    for i, woord in enumerate(lijst):
        if aantal_medeklinkers(woord) == maxi:
            mogelijke_indexen.append(i)
            
    return min(mogelijke_indexen)
    
        


class Woord(object):
    def __init__(self, woord):
        if woord.isalpha():
            self.woord = woord
        else:
            self.woord = "?"
            
    def get_woord(self):
        return self.woord
        
    def __str__(self):
        return "[%s]" % (self.woord)
        
class WoordenBoek(object):
    def __init__(self, lijst_woorden):
        self.lijst_woorden = lijst_woorden
        
    def get_woorden(self):
        return self.lijst_woorden
        
    def get_woord(self, rangnummer):
                
        return self.lijst_woorden[rangnummer].get_woord()
        
    def bereken_metriek(self, metriek):
        return metriek.bereken_metriek(self)
        
class AantalWoordenLangerDan(object):
    
    def __init__(self, lengte):
        self.lengte = lengte
        
    def bereken_metriek(self, wb):
        woordenlijst_objecten = wb.get_woorden()
        woordenlijst = [woord_object.get_woord() for woord_object in woordenlijst_objecten]
        aantal_langer_dan = 0      
        
        for e in woordenlijst:
            if len(e) > self.lengte:
                aantal_langer_dan += 1
                
        return aantal_langer_dan
                
                

            
class IndexMeesteMedeklinkers(object):
     
    def bereken_metriek(self, wb):
        woordenlijst_objecten = wb.get_woorden()
        woordenlijst = [woord_object.get_woord() for woord_object in woordenlijst_objecten]
        
        return index_meeste_medeklinkers(woordenlijst)