class Datum(object):
    aantal_dagen = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    min_jaar = 1900
    @staticmethod
    def _is_geldig(dag, maand, jaar):
        if maand > 0 and maand < 13 and jaar > Datum.min_jaar :
            return dag > 0 and dag <= Datum.aantal_dagen[maand - 1]
        else:
            return False

    def __init__(self, dag, maand, jaar):
        if Datum._is_geldig(dag, maand, jaar):
            self._dag = dag
            self._maand = maand
            self._jaar = jaar
            
                
        else:
            self._dag = 0
            self._maand = 0
            self._jaar = 0
    
    def get_dag(self):
        return self._dag
    
    def get_maand(self):
        return self._maand
    
    def get_jaar(self):
        return self._jaar
    
    def __str__(self): 
        return str(self._dag) + '/' + str(self._maand) +  '/' + str(self._jaar)
        
class NedDatum(Datum):
    
    def __init__(self, dag, maand, jaar):
        Datum.__init__(self, dag, maand, jaar)
    
    lijst = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december']
        
    def __str__(self):
        return '%d %s %d' % (self._dag, NedDatum.lijst[self._maand - 1], self._jaar)
        
class EngDatum(Datum):
    
    def __init__(self, dag, maand, jaar):
        super(EngDatum, self).__init__(dag, maand, jaar)
        self.lijst = lijst = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    def __str__(self):
        return '%s %r, %r' % (self.lijst[self._maand - 1], self._dag, self._jaar)
    