class Speler(object):
    def __init__(self, naam , x, y):
        self.naam = str(naam)
        self.x = x if x >= 0 else 0
        self.y = y if y >= 0 else 0
        
    def get_xy(self):
        return (self.x, self.y)   
    def get_naam(self):
        return self.naam
    def __str__(self):
        return "[%s:<%d,%d>]" % (self.naam, self.x, self.y)
    def __repr__(self):
        return "Speler(%s, %d, %d)" % (self.naam, self.x, self.y)
    def __eq__(self, other):
        return self.naam == other.naam
        
    def ga_rechts(self):
        self.x += 1
        
    def ga_links(self):
        self.x += -1 if self.x != 0 else 0
    
    def ga_boven(self):
        self.y += 1
        
    def ga_onder(self):
        self.y += -1 if self.y != 0 else 0
        
        
        
class BordSpel(object):
    def __init__(self, players=None):
        self.players = [] if players == None else players
        
    def __iadd__(self, mens): 
        
        if mens in self.players:          
            return BordSpel(self.players)
        
        else:
            self.players.append(mens)                        
#           self.players += [mens]
            return BordSpel(self.players)
        
        return BordSpel(self.players)
    
    def get_aantal_spelers_x(self, x):
        aantal_op_x = 0
        for mens in self.players:
            if mens.get_xy()[0] == x:
                aantal_op_x += 1
                
        return aantal_op_x
        
    def is_bezet(self, x, y):
        for mens in self.players:
            if mens.get_xy() == (x, y):
                return True
                
        return False
        
    def filter_spelers(self, objectje):
        
        gefilterde_spelers = []        
        for mens in self.players:
            if objectje.filter(mens):
                gefilterde_spelers.append(str(mens))
                
        return gefilterde_spelers
            
        
class GeefAlles(object):
    def filter(self, mens):
        if isinstance(mens, Speler):
            return True
        return False
        
        
class FilterNaam(object):
    def __init__(self, filter_term):
        self.filter_term = filter_term
        self.lengte = len(filter_term)
    
    def filter(self, mens):
        if isinstance(mens, Speler):
            if (mens.get_naam())[0:self.lengte] == self.filter_term:
                return True
        return False
        
class FilterX(object):
    def __init__(self, x):
        self.x = x
            
    def filter(self, mens):
        if isinstance(mens, Speler):
            if (mens.get_xy())[0] == self.x:
                return True
        return False    