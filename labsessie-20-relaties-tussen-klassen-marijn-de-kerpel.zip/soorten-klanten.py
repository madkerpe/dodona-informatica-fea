##Dit en de vorige code zijn van casper, de 3de laatste versie is van mij maar dodona maakt afrondingsfouten


class Klant(object):
    def __init__(self,naam):
        self._naam = naam
        self._lijst = []       # self want je wilt lijst PER klant
        
    def __iadd__(self,a):
        self._lijst.append(float(a))
        return self
        
    def get_totaal(self):
        #totaal = 0.0
        #for i in self._lijst:
        #    totaal += i.get_totaal()
        #return totaal
        return sum(self._lijst)
        
class GrootHandelaar(Klant):
    def __init__(self,naam,kp=0.1):
        super(GrootHandelaar,self).__init__(naam)
        self._kp = kp
            
    def get_totaal(self):
        return super(GrootHandelaar, self).get_totaal()*(1-self._kp)

class DetailKlant(Klant):
    def get_totaal(self):
        #goedkoopste = min(super(DetailKlant,self).self._lijst)
        #return super(DetailKlant,self).get_totaal()-goedkoopste
    
        return super(DetailKlant,self).get_totaal()-min(self._lijst) if len(self._lijst) > 0 else 0.0


class Kassa(object):
    def __init__(self):
        self._k = []
        
    def registreer_klant(self,kl):
        if isinstance(kl,Klant):
            self._k.append(kl)
        
    def get_kassa_inhoud(self):
        r = 0.0
        for kl in self._k:
            r += kl.get_totaal()*1.0
        return r