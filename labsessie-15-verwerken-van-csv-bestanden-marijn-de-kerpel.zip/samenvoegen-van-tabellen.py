import csv


def merge(input1, input2, output):
    with open(input1, 'r') as infile:
        tabel1 = [rij for rij in csv.reader(infile, delimiter = ';')]
        
    with open(input2, 'r') as infile:
        tabel2 = [rij for rij in csv.reader(infile,delimiter = ';')]
        
    overeenkomst_lijst = []
    
    for rij1 in tabel1[1:]:
        for rij2 in tabel2[1:]:
            
            if rij1[0] + rij1[1] == rij2[0] + rij2[1]:
                overeenkomst_lijst.append(rij2)

    nieuwe_tabel = []
    aantal_vraagtekens = len(tabel2[1]) - 2
    
    for rij in tabel1:
        for vergelijkingsrij in overeenkomst_lijst:
            
        
            if rij[0] == vergelijkingsrij[0] and rij[1] == vergelijkingsrij[1]:
                toevoegsel = rij + vergelijkingsrij[2:]
                break
                
            else:
                toevoegsel = rij + ['?']*aantal_vraagtekens
            
        nieuwe_tabel.append(toevoegsel)
    
    with open(output, 'w') as outfile:
        writer = csv.writer(outfile, delimiter = ';')
        
        writer.writerow(tabel1[0] + tabel2[0][2:])        
        
        for rij in nieuwe_tabel[1:]:
            writer.writerow(rij)    