import csv

def lees_records(bestand):
    
    w = {}
    
    with open(bestand, 'r') as infile:
        tabel = [rij for rij in csv.reader(infile, delimiter = ';')]
        
        
        for j, rij in enumerate(tabel[1:]):
            res = {tabel[0][i]:tabel[j+1][i] for i in range(1, len(tabel[0]))}
            w[rij[0]] = res
            
    return w
