import csv
import numpy as np

def analyseer_dobbelsteen(bestandsnaam):
    with open(bestandsnaam, 'r') as infile:
        tabel = [rij for rij in csv.reader(infile, delimiter = ';')]
    
    lijst_worpen = []
    lijst_frequenties = []
    
    for j in range(len(tabel[0])):
   
        lijst_dobbelsteen = [0.0]*6
        for rij in tabel[1:]:
            if rij[j] != "":    
                lijst_dobbelsteen[int(rij[j]) - 1] += 1
        
        lijst_worpen.append(lijst_dobbelsteen)
    
    
    for rij in lijst_worpen:
        rij = np.array(rij)
        som_rij = np.sum(rij)
        rij /= som_rij
        
        lijst_frequenties.append(list(rij))
        
        
    return lijst_frequenties