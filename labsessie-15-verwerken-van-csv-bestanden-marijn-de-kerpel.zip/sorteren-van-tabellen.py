import csv

#functie die een lijst in een string maakt met spaties tussen
def maak_string(lijst):
	string = ""
	for woord in lijst:
		string += str(woord)
		string += " "
	
	return string[:-1]

def sorteer(source, target, volgorden, reverse=False):
	
	#alles inlezen en de hoofding appart zetten
	with open(source, 'r') as infile:
		tabel = [rij for rij in csv.reader(infile, delimiter = ';')]
		hoofding = tabel[0]
		tabel = tabel[1:]
	
	#specifieke elementen uit de rij halen en met maak_string in de vorm van een string zetten 
	lijst = [maak_string([rij[kolomnummer] for kolomnummer in volgorden]) for rij in tabel]
		
	#volgorde omdraaien als reverse gelijk is aan True
	if reverse:
		gesorteerde_lijst = sorted(lijst, reverse=True)
			
	else:
		gesorteerde_lijst = sorted(lijst, reverse=False)
	
	
	#corresponderende regelnummers uit origineel aan gesorteerde linken	
	volgorde_lijst = [lijst.index(e) for e in gesorteerde_lijst]
	
	#volgens volgorde_lijst tabel construeren
	gesorteerde_tabel = [tabel[i] for i in volgorde_lijst]
	
	#gesorteerde_tabel wegschrijven met hoofding bovenop
	with open(target, 'w') as outfile:
		writer = csv.writer(outfile, delimiter = ';')
		writer.writerow(hoofding)
		for rij in gesorteerde_tabel:
			writer.writerow(rij)