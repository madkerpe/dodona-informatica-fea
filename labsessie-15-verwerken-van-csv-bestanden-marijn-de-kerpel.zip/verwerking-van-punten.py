import csv
import numpy as np
import math


#hulpfunctie, zet float om naar string met 2 decimalen
def naar_string(float):
    res = ("%.2f" % float)
    res = res.replace(".",",")
    
    return str(res)
    
def verwerk_scores(input, output, gewichten):

    ##gegevens inlezen en bewerkingen uitvoeren

    #alles laten inlezen
    with open(input, 'r') as infile:
        tabel = [rij for rij in csv.reader(infile, delimiter = ';')]
        
    #getallen omzetten naar floats
    punten = []
    
    for rij in tabel[1:]:
        punten.append([float(el.replace(",",".")) for el in rij[2:]])
    
    #naar arrays
    gewicht = np.array(gewichten)
    punten = np.array(punten)
    #print("-----originele matrix-----")    
    #print(punten) 
    
    #berekening totaalscore student
    gewogen_som = punten.copy()
    gewogen_som = gewogen_som*gewicht
    
    totaalscore = np.sum(gewogen_som, axis=1)
    #print("-----totaalscore-----")    
    #print(totaalscore)
    #berekening gemiddelde score per vak
    gemiddelde_scores = punten.copy()
    
    gemiddelden = np.mean(gemiddelde_scores, axis=0)
    #print("-----gemiddelden-----")    
    #print(list(gemiddelden))
    
    #berekening gemiddelde totaalscore
    gemiddelde_totaalscore = np.mean(totaalscore)
    
    #spreiding op de scores per vak
    spreiding_getallen = punten.copy()
    factor = 1/(len(punten) - 1)
    spreiding_kwadraat = factor*np.sum(((spreiding_getallen - gemiddelden)*(spreiding_getallen - gemiddelden)), axis=0)
    spreiding = spreiding_kwadraat**(0.5)
    #print("-----spreiding-----")        
    #print(spreiding) 
    
    ##schrijven naar nieuw bestand
    
    #toevoeging getallen aan getallenmatrix
    totaalscore = list(totaalscore)    
    
    i = 0    
    for rij in tabel[1:]:
        rij.append(naar_string(totaalscore[i]))
        i += 1
        
    dubbele_lege = ["",""]
    
    #berekening spreiding_totaalscore
    spreiding_totaalscores_kwadraat = factor*np.sum(((np.asarray(totaalscore) - np.mean(np.asarray(totaalscore)))*(np.asarray(totaalscore) - np.mean(np.asarray(totaalscore)))))
    
    spreiding_totaalscores = spreiding_totaalscores_kwadraat**0.5
    
    
    gemiddelden = dubbele_lege + [naar_string(el) for el in list(gemiddelden)] + [naar_string(np.mean(np.asarray(totaalscore)))]
    spreiding = dubbele_lege + [naar_string(el) for el in list(spreiding)] + [naar_string(spreiding_totaalscores)]
      
    #kak_tabel = [[float(i.replace(',','.')) for i in rij[:2]] for rij in tabel[1:]]  
     
    kak_tabel = []
    kak_tabel.append(tabel[0])
    
    for rij in tabel[1:]:
        kak_lijn = []
        for i in rij[2:]:
            kak_lijn.append(naar_string(float(i.replace(',','.'))))
        
        kak_tabel.append(rij[:2] + kak_lijn)
        
    with open(output, 'w') as outfile:
        writer = csv.writer(outfile, delimiter = ';')
        for rij in kak_tabel:
            writer.writerow(rij)
            
        writer.writerow(gemiddelden)
        writer.writerow(spreiding)