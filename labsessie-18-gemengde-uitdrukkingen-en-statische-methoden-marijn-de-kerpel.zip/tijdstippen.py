class Tijdstip(object):
	
	def __init__(self, uur, minuut, sec):
		
		if uur >= 0 and uur < 24 and minuut >= 0 and minuut < 60 and sec >= 0 and sec < 60:
			self.u = uur
			self.m = minuut
			self.s = sec
			self.decimaal = uur*3600 + minuut*60 + sec
			
		else:
			self.u = 0
			self.m = 0
			self.s = 0
			self.decimaal = 0 
			
	def __str__(self):
			
		if self.u < 10:
			uur_wijzer = "0" + str(self.u)
		else:
			uur_wijzer = str(self.u)
			
		if self.m < 10:
			minuut_wijzer = "0" + str(self.m)
		else:
			minuut_wijzer = str(self.m)
				
		if self.s < 10:
			sec_wijzer = "0" + str(self.s)
		else:
			sec_wijzer = str(self.s)
				
		return "[%s:%s:%s]" % (uur_wijzer, minuut_wijzer, sec_wijzer)
		
	def __repr__(self):
		return "Tijdstip(%r, %r, %r)" % (self.u, self.m, self.s)
			
	def __eq__(self, other):
		return self.u == other.u and self.m == other.m and self.s == other.s
	def __lt__(self, other):
		return self.decimaal < other.decimaal
	def __le__(self, other):
		return self.decimaal <= other.decimaal
		
	def __add__(self, other):
		if hasattr(other, "decimaal"):
			nieuwe_s = self.s + other.s
			nieuwe_m = self.m + other.m + nieuwe_s//60
			nieuwe_u = self.u + other.u + nieuwe_m//60
			
			return Tijdstip(nieuwe_u%24, nieuwe_m%60, nieuwe_s%60)
			
			
			
		else:
			nieuwe_decimaal = self.decimaal + other
			nieuwe_u = (nieuwe_decimaal//3600)%24
			nieuwe_m = ((nieuwe_decimaal - nieuwe_u*3600)//60)%60
			nieuwe_s = (nieuwe_decimaal - nieuwe_u*3600 - 60*nieuwe_m)%60
			return Tijdstip(nieuwe_u, nieuwe_m, nieuwe_s)
			
	def __radd__(self, other):
		
		nieuwe_decimaal = self.decimaal + other
		nieuwe_u = (nieuwe_decimaal//3600)%24
		nieuwe_m = ((nieuwe_decimaal - nieuwe_u*3600)//60)%60
		nieuwe_s = (nieuwe_decimaal - nieuwe_u*3600 - 60*nieuwe_m)%60
		return Tijdstip(nieuwe_u, nieuwe_m, nieuwe_s)