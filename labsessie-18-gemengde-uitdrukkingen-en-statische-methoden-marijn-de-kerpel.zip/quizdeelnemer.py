def xor(b1, b2):
    return (b1 or b2) and (not (b1 and b2))
    
def xand(b1, b2):
    return not xor(b1, b2)

class QuizDeelnemer(object):
    juiste_antwoorden = [] 
    aantal_vragen = 0
    voorkomende_score = []
    
    def __init__(self, naam):
        self.naam = naam
    
    @staticmethod
    def set_juiste_antwoorden(juiste_antwoorden):
        QuizDeelnemer.juiste_antwoorden = juiste_antwoorden
        QuizDeelnemer.aantal_vragen = len(juiste_antwoorden)        
       
    def bereken_score(self, antwoorden):
        correct = 0
        
        if len(antwoorden) == QuizDeelnemer.aantal_vragen:
            for i,bja in enumerate(QuizDeelnemer.juiste_antwoorden):
                if xand(antwoorden[i] ,bja):
                    correct += 1
                    
        QuizDeelnemer.laatste_score = correct
        QuizDeelnemer.voorkomende_score.append(correct)
        return correct
    
    def __str__(self):
        teller = QuizDeelnemer.laatste_score
        noemer = QuizDeelnemer.aantal_vragen       
        return "[%s:%d/%d]" % (self.naam, teller, noemer)
    
    @staticmethod
    def get_max_score():
        return max(QuizDeelnemer.voorkomende_score)
        
    @staticmethod
    def reset_max_score():
        QuizDeelnemer.voorkomende_score = []