class Kortingkaart(object):
    totale_korting = 0

    def __init__(self, naam, N, kp, aankopen=None):
        self.naam = naam
        self.N = N
        self.kp = kp
        if aankopen == None:
            self.aankopen = []
        else:
            self.aankopen = aankopen            
        
        
    def __iadd__(self, aankoop):
        self.aankopen.append(aankoop)        
        return self
        
    def __eq__(self, other):
        return self.naam == other.naam
        
    def __add__(self, other):
        if self == other:
            nieuwe_aankopen = self.aankopen + other.aankopen
            self.aankopen = []
            other.aankopen = []
            
            nieuwe_N = max([self.N, other.N])
            nieuwe_kp = min([self.kp, other.kp])
            
        else:
            return self
        
        return Kortingkaart(self.naam, nieuwe_N, nieuwe_kp, nieuwe_aankopen)
        
    def vraag_korting(self):
        
        aantal_schijven = len(self.aankopen)//self.N        
        kortingbedrag = sum(self.aankopen[:aantal_schijven*self.N])        
        self.aankopen = self.aankopen[aantal_schijven*self.N:]     
        Kortingkaart.totale_korting += kortingbedrag*self.kp
        
        return kortingbedrag*self.kp
        
    def __str__(self):
        return "[%s:N=%d:P=%f:S=%f:A=%d]" % (self.naam, self.N, self.kp, sum(self.aankopen), len(self.aankopen))
        
    @staticmethod
    def get_totale_korting():
        return Kortingkaart.totale_korting
        
    @staticmethod
    def reset_totale_korting():
        Kortingkaart.totale_korting = 0
        
        