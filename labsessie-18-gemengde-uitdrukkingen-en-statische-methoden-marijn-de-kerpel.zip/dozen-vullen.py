class Doos(object):
    
    aantal_volle_dozen = 0
    
    def __init__(self, naam, cap, massas=None):
    	
    	self.naam = naam
    	self.cap = cap
    	self.massas = [] if massas is None else massas
    	
    def __iadd__(self, other):
    	
    	if sum(self.massas) + other < self.cap:
    		
    		self.massas.append(other)
    		return Doos(self.naam, self.cap, self.massas)
    	
    	elif sum(self.massas) + other == self.cap:
    		
    		Doos.aantal_volle_dozen += 1
    		
    		self.massas.append(other)
    		return Doos(self.naam, self.cap, self.massas)
    		
    	else:
    		return self
    		
    		
    def  __str__(self):
    	
    	return "[%s:%s:C=%d:I=%d]" % (self.naam, self.massas, self.cap, sum(self.massas))
    
    @staticmethod	
    def get_aantal_volle_dozen():
    	return Doos.aantal_volle_dozen
    
    @staticmethod	
    def reset_aantal_volle_dozen():
    	Doos.aantal_volle_dozen = 0