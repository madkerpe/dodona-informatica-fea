import numpy as np

class Interval(object):
	
	def __init__(self, x, y):
		self.x = x
		self.y = y
	def __str__(self):
		return "[%.2f,%.2f]" % (self.x, self.y)
	def __repr__(self):
		return "Interval(%r,%r)" % (self.x, self.y)
	def __eq__(self, other):
		return np.allclose(self.x, other.x) and np.allclose(self.y, other.y)
		
	def __add__(self, other):
		if hasattr(other, "x") and hasattr(other, "y"):
			return Interval(self.x + other.x, self.y + other.y)
			
		else:
			return Interval(self.x + other, self.y + other)
	def __sub__(self, other):
		if hasattr(other, "x") and hasattr(other, "y"):
			return Interval(self.x - other.y, self.y - other.x)
			
		else:
			return Interval(self.x - other, self.y - other)
	def __mul__(self, other):
		if hasattr(other, "x") and hasattr(other, "y"):
			
			x1 = self.x
			x2 = self.y
			y1 = other.x
			y2 = other.y
			
			nieuwe_x = min(x1*y1, x1*y2, x2*y1, x2*y2)
			nieuwe_y = max(x1*y1, x1*y2, x2*y1, x2*y2)
			
			return Interval(nieuwe_x, nieuwe_y)
			
		else:
			nieuwe_x = min(self.x*other, self.y*other)
			nieuwe_y = max(self.x*other, self.y*other)
			
			return Interval(nieuwe_x, nieuwe_y)
	def __truediv__(self, other):
		if hasattr(other, "x") and hasattr(other, "y"):
			
			x1 = self.x
			x2 = self.y
			y1 = other.x
			y2 = other.y
			
			return Interval(x1, x2).__mul__(Interval(1.0/y2, 1.0/y1))
		
		else:
			nieuwe_x = min(self.x/other, self.y/other)
			nieuwe_y = max(self.x/other, self.y/other)
			
			return Interval(nieuwe_x, nieuwe_y)
			
	def __radd__(self, other):
		return Interval(self.x + other, self.y + other)
	def __rmul__(self, other):
		nieuwe_x = min(self.x*other, self.y*other)
		nieuwe_y = max(self.x*other, self.y*other)
		return Interval(nieuwe_x, nieuwe_y)
		
		