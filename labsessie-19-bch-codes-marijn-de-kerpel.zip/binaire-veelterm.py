##2de versie

import numpy as np

def modulo2(lijst):
    uniek_element = []
    for e in lijst:
        if lijst.count(e)%2 == 1:
            uniek_element.append(e)
    return uniek_element



class BinaireVeelterm(object):

    def __init__(self, lijst):
        uniek_element = []
        
        for e in lijst:
            if e >= 0 and e not in uniek_element:
                uniek_element.append(e)
    
        self.coeff = sorted(uniek_element, reverse=True)
        
        if lijst != []:
            self.niet_nul = True
            self.graad = max(self.coeff)
            
            coef = [0]*self.graad + [0]
            for e in self.coeff:
                coef[e] = 1
            
            self.bin = coef

        else:
            self.niet_nul = False
            self.graad = 0
            self.bin = [0]
            
            
            
    
    def __str__(self):
            
        string = ""
        
        if self.niet_nul and 0 in self.coeff:
            for i in self.coeff[:-1]:                
                string += "x**%s+" % i
        
            string += "1"
        
        elif self.niet_nul and 0 not in self.coeff:
            for i in self.coeff[:-1]:                
                string += "x**%s+" % i
        
            string += "x**%s" % self.coeff[-1]

        else:
            string = 0
            
        return str(string)
        
    def __repr__(self):
        return "BinaireVeelterm(%s)" % self.coeff
        
    def __eq__(self, other):
        return self.coeff == other.coeff
        
    def get_graad(self):
        return self.graad
        
    def get_coef(self):
        return self.bin
        
    def __add__(self , other):
        volledige_som = self.coeff + other.coeff
        som = []
        for e in volledige_som:
            if volledige_som.count(e) == 1:
                som.append(e)
        
        return BinaireVeelterm(som)
        
    def __mul__(self, other):
        product = []        
        
        for a in self.coeff:
            for b in other.coeff:
                product.append(a+b)
                
                
        return BinaireVeelterm(modulo2(product))
        
        
        
        
        