import numpy as np
def modulo2(lijst):
    uniek_element = []
    for e in lijst:
        if lijst.count(e)%2 == 1:
            uniek_element.append(e)
    return uniek_element
def veelterm_input(lijst):
	voorwaarde = np.asarray(lijst, dtype=bool)
	plaats = np.arange(len(lijst))
	return list(plaats[voorwaarde])
def hamming(bin1, bin2):
    verschil = abs(len(bin1)-len(bin2))
    if len(bin1) > len(bin2):
        langste = bin1
        kortste = bin2
    elif len(bin1) < len(bin2) or len(bin1) == len(bin2):
        langste = bin2
        kortste = bin1
    
    
    ongelijkheden = 0
    
    for index, letter in enumerate(kortste):
        if letter != langste[index]:
            ongelijkheden += 1
    
    
    
    return int(verschil + ongelijkheden)
	


class BinaireVeelterm(object):

    def __init__(self, lijst):
        uniek_element = []
        
        for e in lijst:
            if e >= 0 and e not in uniek_element:
                uniek_element.append(e)
    
        self.coeff = sorted(uniek_element, reverse=True)
        
        if lijst != []:
            self.niet_nul = True
            self.graad = max(self.coeff)
            
            coef = [0]*self.graad + [0]
            for e in self.coeff:
                coef[e] = 1
            
            self.bin = coef

        else:
            self.niet_nul = False
            self.graad = 0
            self.bin = [0]
            
            
            
    
    def __str__(self):
            
        string = ""
        
        if self.niet_nul and 0 in self.coeff:
            for i in self.coeff[:-1]:                
                string += "x**%s+" % i
        
            string += "1"
        
        elif self.niet_nul and 0 not in self.coeff:
            for i in self.coeff[:-1]:                
                string += "x**%s+" % i
        
            string += "x**%s" % self.coeff[-1]

        else:
            string = 0
            
        return str(string)
        
    def __repr__(self):
        return "BinaireVeelterm(%s)" % self.coeff
        
    def __eq__(self, other):
        return self.coeff == other.coeff
        
    def get_graad(self):
        return self.graad
        
    def get_coef(self):
        return self.bin
        
    def __add__(self , other):
        volledige_som = self.coeff + other.coeff
        som = []
        for e in volledige_som:
            if volledige_som.count(e) == 1:
                som.append(e)
        
        return BinaireVeelterm(som)
        
    def __mul__(self, other):
        product = []        
        
        for a in self.coeff:
            for b in other.coeff:
                product.append(a+b)
                
                
        return BinaireVeelterm(modulo2(product))
      
class Code(object):
	
	def __init__(self, n, m, v):
		
		if n > 0 and m >= 0 and n >= m and v.get_graad() == n - m:
			self.n = n
			self.m = m
			self.v = v
			self.geldig = True
		
		else:
			self.geldig = False
	def get_n(self):
		if self.geldig:
			return self.n
		return -1
	def get_m(self):
		if self.geldig:
			return self.m
		return -1
	def __str__(self):
		if self.geldig:	
			return "(%d,%d)[%s]" % (self.n, 2**self.m, self.v)
		return "(-1,0)[None]"
	def __repr__(self):
		return "Code(%d,%d,%r)" % (self.n, self.m, self.v)
	def __eq__(self, other):
		return self.__dict__ == other.__dict__
	def codeer(self, M):
		if self.geldig and len(M) == self.m:
			irri = self.v
			beri = BinaireVeelterm(veelterm_input(M))
			gecodeerde_veelterm = (irri*beri).get_coef()
			while len(gecodeerde_veelterm) < self.n:
				gecodeerde_veelterm += [0]
			
			return gecodeerde_veelterm
		
		return []
	def decodeer(self, C):
		if self.geldig:	
			imax = 2**self.m - 1
			for decimaal in range(imax):
				binair = bin(decimaal)[2:]
				veelterm = []
				for bit in binair:
					veelterm.append(int(bit))
			
				veelterm = (self.m - len(veelterm))*[0] +  veelterm  
			
				if C == self.codeer(veelterm):
					return veelterm
			
		return []
		
	def corrigeer(self, C):
		
		if self.geldig:	
			imax = 2**self.m - 1
			hamming_lijst = []
			for decimaal in range(imax):
				binair = bin(decimaal)[2:]
				veelterm = []
				for bit in binair:
					veelterm.append(int(bit))
			
				veelterm = (self.m - len(veelterm))*[0] +  veelterm  
				hamming_lijst.append(hamming(C, self.codeer(veelterm)))
				
		##constructie_antwoord
		antwoord = hamming_lijst.index(min(hamming_lijst))
		
		binair = bin(antwoord)[2:]
		veelterm = []
		for bit in binair:
			veelterm.append(int(bit))
		
		return (self.m - len(veelterm))*[0] +  veelterm
		
		
