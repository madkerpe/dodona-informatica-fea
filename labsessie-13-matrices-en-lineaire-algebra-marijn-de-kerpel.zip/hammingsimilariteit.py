import numpy as np

def hamming(tabel):
    M, N = tabel.shape
    res = np.array([1]*M*M)
    res = res.reshape(M, M)
    res_lijst = []
    
#    print(res)
    
    
    for i, e in np.ndenumerate(res):
#        print(i)
        
        eerste_rij = tabel[i[0]]
        tweede_rij = tabel[i[1]]
        ham = 0
        
        for j, e in enumerate(eerste_rij):
#            print("-------------------------------")
#            print(eerste_rij)
#            print(tweede_rij)
            ham += np.sum((e != tweede_rij[j]))
#            print(ham)
#            print("-------------------------------")
            
        res_lijst.append(ham)
        
    return np.array(res_lijst).reshape(M,M)