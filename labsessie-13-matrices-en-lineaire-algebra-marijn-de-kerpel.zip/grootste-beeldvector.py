import numpy as np

def grootste_beeldvector(A, B):
	N, M = B.shape
	lijst_kolomvectoren = []
	
	for j in range(M):
		lijst_kolomvectoren.append(np.linalg.norm(A*B[:,j]))
	
	index = lijst_kolomvectoren.index(max(lijst_kolomvectoren))
	return np.array(B[:,index])	