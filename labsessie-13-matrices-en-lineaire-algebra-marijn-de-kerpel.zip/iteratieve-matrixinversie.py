import numpy as np

def lam(A):
	Y = (A)*(A.T)
	normlijst = []
	
	for i in range(len(Y)):
		#norm = float(np.linalg.norm(Y[i], 1))
		 
		norm = np.sum(abs(Y[i]))
		
		normlijst.append(norm)
	return 1.0/max(normlijst)
	
def inverteer_iteratief(A, f):
	X0 = lam(A)*(A.T)
	X = X0
	
	while np.linalg.norm((A*X) - np.eye(len(A*X))) >= f:
		
	    X = X*(2*np.eye(len(X)) - A*X)
	
	return X