import numpy as np

def zoek_som(A):
	# A[:,k] = A[:,i] + A[:,j]
	# [i,j,k]
	
	n = A.shape[1]
	oplossingenlijst = []

	for i in range(n):
		for j in range(n):
			for k in range(n):
				if  i < j and i != k and j != k:
					rij = A[:,k]
					som = A[:,i] + A[:,j]
					voorwaarde = np.all(rij == som)
					
					if voorwaarde:
						oplossingenlijst.append((i,j,k))
				
	return np.matrix(oplossingenlijst)	