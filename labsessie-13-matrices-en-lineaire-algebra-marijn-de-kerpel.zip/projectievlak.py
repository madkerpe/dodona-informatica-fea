import numpy as np

def projectievlak(P):
	eigenwaarden, eigenvectoren  = np.linalg.eig(P)
	u_en_v = []
	
	for i, e in enumerate(eigenwaarden):
		if abs(e - 1) < 10**(-6):
			u_en_v.append(eigenvectoren[:,i])
			
	u_en_v = np.array(u_en_v)
	n = np.cross(np.transpose(u_en_v[0]), np.transpose(u_en_v[1]))
	
	#x component positief maken
	if n[0,0] < 0:
		n = n*(-1)
		
	n /= np.linalg.norm(n)
	return np.transpose(n)