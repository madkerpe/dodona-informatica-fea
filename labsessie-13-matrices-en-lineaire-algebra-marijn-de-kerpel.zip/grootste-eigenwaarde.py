import numpy as np

def grootste_eigenwaarde(A, x0, f):
    xn = x0
    xn1 = (1/np.linalg.norm(A*xn))*(A*xn)
    while np.linalg.norm(xn1 - xn) > f:
        xn = xn1
        xn1 = (1/np.linalg.norm(A*xn))*(A*xn)
        
    
    return xn1 , np.linalg.norm(A*xn)