import numpy as np

def codeer(C, x):
    n, m = C.shape
    
    while len(x)%n != 0:
        x = np.append(x, 0)    
    
    
    gecodeerde = np.dot(np.matrix(C), np.transpose(x[0:n]))
    
    
    for i in range(1, int(len(x)/n)):
    	
    	temp_gecodeerde = np.dot(np.matrix(C), np.transpose(x[n*i:(i+1)*n]))
    	gecodeerde = np.append(gecodeerde, temp_gecodeerde, axis=1)
    
    
    return np.array(gecodeerde)[0]
    
    
def decodeer(D, x):
    n, m = D.shape
    
    while len(x)%n != 0:
        x = np.append(x, 0)
        
    gedecodeerde = np.dot(np.linalg.inv(np.matrix(D)), np.transpose(x[0:n]))
    
    
    
    for i in range(1, int(len(x)/n)):
    	
    	temp_gedecodeerde = np.dot(np.linalg.inv(np.matrix(D)), np.transpose(x[n*i:(i+1)*n]))
    	gedecodeerde = np.append(gedecodeerde, temp_gedecodeerde, axis=1)
    return np.array(gedecodeerde)[0]