
x = int(input())
is_priem = 1
i = 2
 
while i < x:
    
    is_priem *= x%i 
    i += 1
    
print(is_priem != 0 and x!= 1)  