n = float(input())
c = float(input())
ai = 1
i = 1

while abs(n - (ai**2))  >  c: 
    ai = 0.5*(ai + (n/ai))
    i += 1
    
print(ai)
print(i - 1)
    
