import math

a = int(input())
i = 0

while a != 1:
    i += 1
    a = (a%2)*(3*a + 1) + ((a + 1)%2)*(a/2) 
    
    


print(i)