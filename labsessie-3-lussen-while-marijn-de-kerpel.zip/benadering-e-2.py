import math

x = float(input())
term = x + 1
aantal_termen = 0
benadering_e = 0
i = 0

while term > x:
    aantal_termen += 1
    term = 1/math.factorial(i)
    benadering_e += term
    i += 1

print(benadering_e - term)
print(aantal_termen - 1)