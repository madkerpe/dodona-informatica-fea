n = int(input())
lengte = 0
a = n
aantal_eens = a%2

while a//10 > 1:
       
    a //= 10
    lengte += 1
    aantal_eens += a%2
    

print((n*10) + ((aantal_eens + 1)%2))