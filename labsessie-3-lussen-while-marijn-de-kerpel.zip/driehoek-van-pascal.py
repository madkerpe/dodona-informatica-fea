import math

regelnummer = int(input())
i = regelnummer + 1
k = 0

while i > 0 :
    n = regelnummer
    nk = int((math.factorial(n))/(math.factorial(n-k)*math.factorial(k)))
    print(nk, end='\t')
    k += 1
    i -= 1
    