a = int(input())
b = int(input())

while a%2 == 0:
    a += 1
    


while a <= b:
    print(a, end='\t')
    a += 2
    
    
    
    
    
