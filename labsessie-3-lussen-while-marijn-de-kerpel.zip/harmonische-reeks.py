import math

N = float(input())
harmonische_som = 0
i = 0
n = 1

while N >= harmonische_som:
     i += 1
     harmonische_som += (1/i)
     
    
    
print(i)