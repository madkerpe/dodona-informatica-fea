import numpy as np


def zoek(rij,lijst_functies):
    
    temp_rij = rij.copy()
    temp_bool = np.ones(len(rij))
    
    for functie in lijst_functies:
        temp_rij = rij.copy()
        temp_bool = np.logical_and(temp_bool, functie(temp_rij))
    
    
    return [int(i) for i in np.arange(len(rij))[temp_bool]]
    #list(np.arange(len(rij))[temp_bool])