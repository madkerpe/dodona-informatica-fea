import numpy as np

def drempel(x, a, b):
    x = np.where(x >= a, (x-a)/b, 0)
    return x