import numpy as np

def uitmiddeling(rij , M):
    N = len(rij)//M
    lijst = []
    
    for i in range(N):
        lijst.append(np.mean(rij[i::N]))
        
    return np.array(lijst)
    