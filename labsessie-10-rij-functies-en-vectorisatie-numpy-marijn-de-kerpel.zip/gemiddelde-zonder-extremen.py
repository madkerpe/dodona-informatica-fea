import numpy as np

def gemiddeldeZonderExtremen(rij):
    rij.sort()
    zonder_hoogste = np.mean(rij[:-1:])
    zonder_laagste = np.mean(rij[1::])
    
    return (zonder_hoogste, zonder_laagste)