import numpy as np

def groepen(rij):
    resultaatlijst = []
        
    for i in range(np.max(rij) + 1):
        range_rij = np.arange(len(rij)) 
        range_rij = range_rij[rij == i]              
                
        resultaatlijst.append(range_rij)
    return resultaatlijst