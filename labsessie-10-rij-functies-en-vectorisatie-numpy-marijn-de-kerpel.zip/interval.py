import numpy as np

def I(x, a, b):

    return np.logical_and((x >= a), (x < b))*1