import numpy as np

def I(x, a, b):

    return np.logical_and((x >= a), (x < b))*1.0
    
    
def stukConst(rij, lijst_triplets):

    resultaat = np.zeros_like(rij)
    for i in range(len(lijst_triplets)):
        a = lijst_triplets[i][0]
        b = lijst_triplets[i][1]
        c = lijst_triplets[i][2]
        
        #a,b,c = lijst_triplets[i]
    
        resultaat += c*I(rij,a,b)
        
    return resultaat