import numpy as np

def kamerGemiddelde(rij):
    
    gemiddelde = np.mean(rij)
    
    dag = rij[gemiddelde <= rij]
    nacht = rij[gemiddelde >= rij]
    
    return (np.mean(nacht), np.mean(dag))