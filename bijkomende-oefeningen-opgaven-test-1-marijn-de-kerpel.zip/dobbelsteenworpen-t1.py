def somWorp(lijst, som):
	
	resultaat = []
	
	for worp in lijst:
		if sum(worp) == som:
			resultaat.append(worp)
	
	return resultaat
	