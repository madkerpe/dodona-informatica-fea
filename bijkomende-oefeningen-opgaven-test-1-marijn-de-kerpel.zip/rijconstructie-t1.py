def genereerRij(f, a0, a1, n=10):
    
    resultaten = [a0, a1]
    i = 0
    
    while len(resultaten) < n:
        resultaten.append(f(resultaten[i+1], resultaten[i]))
        i += 1
    
    return resultaten