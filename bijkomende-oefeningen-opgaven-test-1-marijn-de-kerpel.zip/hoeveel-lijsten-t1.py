###vorige zonder list comprehension

def bouwLijsten(p, N):
    return min([p.count(i) for i in range(1, N + 1)])