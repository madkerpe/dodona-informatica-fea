import numpy as np

def reconstrueer(V, Vhoog, Vlaag):
    
    V = np.asarray(V)
    gemiddelde = (Vhoog + Vlaag)/2
    voorwaarde = V > gemiddelde
    
    return voorwaarde*1
    