def groepjes(lijst, N):
    
    temp_tup = []
    resultaat_lijst = []
    
    for i in lijst:
        temp_tup.append(i)
        if sum(temp_tup) > N:
            resultaat_lijst.append(tuple(temp_tup))
            temp_tup = []
    
    if len(temp_tup) != 0:
        resultaat_lijst.append(tuple(temp_tup))
    
    return resultaat_lijst
    