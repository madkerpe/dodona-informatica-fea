def kopie(lijst):
    for lengte_interval in range(1, len(lijst) + 1):
        if len(lijst) % lengte_interval == 0:
            opsplitsing = []
            for i in range(len(lijst)//lengte_interval):
                
                opsplitsing.append(lijst[i*lengte_interval:(i + 1)*lengte_interval])
            
            if opsplitsing.count(opsplitsing[0]) == len(lijst)//lengte_interval:
                
                return len(lijst)//lengte_interval