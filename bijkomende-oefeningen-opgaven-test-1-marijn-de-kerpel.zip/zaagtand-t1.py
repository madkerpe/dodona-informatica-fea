def zaagtand(x, a):
    return x%a