import numpy as np

def openRing(x, y, r_1, r_2):
    straal = np.sqrt(x**2 + y**2)
    min = r_1 < straal
    max = r_2 > straal
    
    correct = np.logical_and(min, max)
    return np.sum(correct)