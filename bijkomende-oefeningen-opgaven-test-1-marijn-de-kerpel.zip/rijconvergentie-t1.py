def convergent(f, eps=0.001, MaxIter=1000):
	
	for i in range(MaxIter):
		if abs(f(i) - f(i+1)) < eps:
			return i
			
	return -1