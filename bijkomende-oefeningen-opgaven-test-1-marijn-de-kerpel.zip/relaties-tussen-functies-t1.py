def relatie(f, g, a, b, delta=0.01):
    
    xi = a
    i = 0
    f_groter = 0
    g_groter = 0
    
    while xi <= b:
        
        if f(xi) > g(xi):
            f_groter += 1
        
        elif f(xi) < g(xi):
            g_groter += 1
        
        xi += delta
        i += 1
        
    x1 = 0
    x2 = 0
    
    if f_groter == i:
        x2 += 1
        
    if g_groter == i:
        x1 += 1
        
   
    
    return (x1,x2)