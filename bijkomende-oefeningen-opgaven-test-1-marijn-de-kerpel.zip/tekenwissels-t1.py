def tekenwissels(f, a, b, eps=0.01):
    
    aantal_tekenwissels = 0
    i = a
    nieuwe = a
    eerste_keer = 1
    
    while i < b:
        
        vorige = nieuwe
        nieuwe = f(i)
        
        if nieuwe*vorige <= 0 and eerste_keer != 1:
            aantal_tekenwissels += 1
        
        eerste_keer *= 0
        i += eps
        
    return aantal_tekenwissels
    
    